package wx;

// -----( IS Java Code Template v1.2
//
// WxGaugeMetrics — in-process, license-free sag_is_* exporter.
// render:        builds Prometheus exposition text and returns it as the HTTP response.
// registerAlias: startup service; maps /gauge/metrics -> invoke/wx.gaugeMetrics:render (no license check).
//
// Metric sources (all license-free, confirmed under PIESS / Microservices=no):
//   Task 1 (this file): JVM/OS families via java.lang.management + com.sun.management MXBeans.
//   Task 2 (todo):      per-service families via wm.server.query:getServiceStats.
//   Task 3 (todo):      server-aggregate families via wm.server.query:getStats.
// Names/HELP/TYPE mirror the MSR native endpoint (frozen golden capture) so dashboards are source-agnostic.
// No per-line timestamp — Prometheus stamps at scrape (avoids VM-clock-jump TSDB poisoning).

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryUsage;
import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ThreadMXBean;
import java.lang.management.ThreadInfo;
import java.lang.management.ClassLoadingMXBean;
import java.lang.management.BufferPoolMXBean;
import java.net.InetAddress;
import java.io.File;
import java.util.List;
// --- <<IS-END-IMPORTS>> ---

public final class gaugeMetrics
{
	// ---( internal utility methods )---

	final static gaugeMetrics _instance = new gaugeMetrics();

	static gaugeMetrics _newInstance() { return new gaugeMetrics(); }

	static gaugeMetrics _cast(Object o) { return (gaugeMetrics)o; }

	// ---( server methods )---

	public static final void render (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(render)>> ---
		// @sigtype java 3.5
		StringBuilder sb = new StringBuilder(16384);
		String host = hostname();
		String hostLbl = "host=\"" + host + "\"";

		long uptimeSec = ManagementFactory.getRuntimeMXBean().getUptime() / 1000L;
		header(sb, "sag_is_uptime_seconds", "Uptime for Server", "counter");
		line(sb, "sag_is_uptime_seconds", hostLbl, uptimeSec);

		try { collectJvm(sb, host, hostLbl); } catch (Throwable t) { /* best-effort, like native */ }
		try { collectServer(sb, hostLbl); } catch (Throwable t) { /* best-effort, like native */ }
		// DEFERRED — per-service families (collectServiceStats) are NOT emitted by MCR /metrics
		// (sag-is-catalog.md 'Service metrics' section is Live:— on MCR; getServiceStats returns
		// every loaded service, which is snapshot noise). Re-enable when we add service metrics.
		// try { collectServiceStats(sb, hostLbl); } catch (Throwable t) {}

		writeResponse(sb.toString());
		// --- <<IS-END>> ---
	}

	public static final void registerAlias (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(registerAlias)>> ---
		// @sigtype java 3.5
		// Idempotent + self-healing: drop any stale/malformed alias first, then add cleanly.
		try {
			IData del = IDataFactory.create();
			IDataCursor dc = del.getCursor();
			IDataUtil.put(dc, "alias", "gauge/metrics");
			dc.destroy();
			Service.doInvoke("wm.server.httpUrlAlias", "deleteAlias", del);
		} catch (Exception ignore) { /* not present yet — fine */ }

		IData in = IDataFactory.create();
		IDataCursor c = in.getCursor();
		IDataUtil.put(c, "alias", "gauge/metrics");
		IDataUtil.put(c, "urlPath", "invoke/wx.gaugeMetrics:render");
		// association="1" is what makes a multi-segment alias (gauge/metrics) resolve;
		// isDefaultPath="true" here silently produces an alias with no usable urlPath.
		IDataUtil.put(c, "association", "1");
		IDataUtil.put(c, "package", "WxGaugeMetrics");
		c.destroy();
		try { Service.doInvoke("wm.server.httpUrlAlias", "addAlias", in); }
		catch (Exception e) { throw new ServiceException(e); }
		// --- <<IS-END>> ---
	}

	// --- <<IS-START-SHARED>> ---

	private static final long MB = 1024L * 1024L;

	// ===== Task 1: JVM + OS families (28) — all license-free MXBeans =====
	static void collectJvm(StringBuilder sb, String host, String hostLbl)
	{
		// --- Memory: heap / non-heap used mbytes ---
		MemoryMXBean mem = ManagementFactory.getMemoryMXBean();
		header(sb, "sag_is_jvm_memory_heap_used_mbytes", "The total number of allocated megabytes from heap memory", "gauge");
		line(sb, "sag_is_jvm_memory_heap_used_mbytes", hostLbl, mem.getHeapMemoryUsage().getUsed() / MB);
		header(sb, "sag_is_jvm_memory_nonheap_used_mbytes", "The total number of allocated megabytes NOT from heap memory", "gauge");
		line(sb, "sag_is_jvm_memory_nonheap_used_mbytes", hostLbl, mem.getNonHeapMemoryUsage().getUsed() / MB);

		// --- objects pending finalizer ---
		header(sb, "sag_is_jvm_objects_pending_finalizer_count", "The number of objects ready for GC", "gauge");
		line(sb, "sag_is_jvm_objects_pending_finalizer_count", hostLbl, mem.getObjectPendingFinalizationCount());

		// --- Memory pools: pool_max_mbytes (value = used MB, per native) {name,host,poolType} ---
		header(sb, "sag_is_jvm_memory_pool_max_mbytes", "The total number of allocated megabytes in the named memory pool", "gauge");
		for (MemoryPoolMXBean p : ManagementFactory.getMemoryPoolMXBeans()) {
			MemoryUsage u = p.getUsage();
			long mb = (u != null) ? u.getUsed() / MB : 0L;
			String lbl = "name=\"" + enc(p.getName()) + "\"," + hostLbl + ",poolType=\"" + p.getType().name() + "\"";
			line(sb, "sag_is_jvm_memory_pool_max_mbytes", lbl, mb);
		}

		// --- NIO buffer pools: buffer_pool_capacity_mbytes {name,host} ---
		header(sb, "sag_is_jvm_memory_buffer_pool_capacity_mbytes", "The total number of allocated megabytes from NIO buffer pools", "gauge");
		for (BufferPoolMXBean bp : ManagementFactory.getPlatformMXBeans(BufferPoolMXBean.class)) {
			String lbl = "name=\"" + enc(bp.getName()) + "\"," + hostLbl;
			line(sb, "sag_is_jvm_memory_buffer_pool_capacity_mbytes", lbl, bp.getTotalCapacity() / MB);
		}

		// --- GC: gc_collection_millis {name,host} ---
		header(sb, "sag_is_jvm_gc_collection_millis", "The total milliseconds from garbage collection cycle", "gauge");
		for (GarbageCollectorMXBean gc : ManagementFactory.getGarbageCollectorMXBeans()) {
			String lbl = "name=\"" + enc(gc.getName()) + "\"," + hostLbl;
			line(sb, "sag_is_jvm_gc_collection_millis", lbl, gc.getCollectionTime());
		}

		// --- Classes ---
		ClassLoadingMXBean cl = ManagementFactory.getClassLoadingMXBean();
		header(sb, "sag_is_jvm_classes_loaded_total", "The total number of current classes loaded in the JVM", "gauge");
		line(sb, "sag_is_jvm_classes_loaded_total", hostLbl, cl.getLoadedClassCount());
		header(sb, "sag_is_jvm_classes_total", "The total number of classes ever loaded in the JVM since startup", "gauge");
		line(sb, "sag_is_jvm_classes_total", hostLbl, cl.getTotalLoadedClassCount());
		header(sb, "sag_is_jvm_classes_unloaded_total", "The total number of classes unloaded in the JVM since startup", "gauge");
		line(sb, "sag_is_jvm_classes_unloaded_total", hostLbl, cl.getUnloadedClassCount());

		// --- Threads: per-state counts + aggregates ---
		ThreadMXBean th = ManagementFactory.getThreadMXBean();
		try { if (th.isThreadContentionMonitoringSupported() && !th.isThreadContentionMonitoringEnabled())
				th.setThreadContentionMonitoringEnabled(true); } catch (Throwable ignore) {}
		long[] ids = th.getAllThreadIds();
		ThreadInfo[] infos = th.getThreadInfo(ids);
		long sNew=0, sRunnable=0, sBlocked=0, sWaiting=0, sTimed=0, sTerminated=0;
		long nativeCnt=0, suspendCnt=0, blockedCnt=0, waitedCnt=0, blockedMs=0, waitedMs=0;
		for (ThreadInfo ti : infos) {
			if (ti == null) continue;
			switch (ti.getThreadState()) {
				case NEW: sNew++; break;
				case RUNNABLE: sRunnable++; break;
				case BLOCKED: sBlocked++; break;
				case WAITING: sWaiting++; break;
				case TIMED_WAITING: sTimed++; break;
				case TERMINATED: sTerminated++; break;
			}
			if (ti.isInNative()) nativeCnt++;
			if (ti.isSuspended()) suspendCnt++;
			blockedCnt += ti.getBlockedCount();
			waitedCnt  += ti.getWaitedCount();
			long bt = ti.getBlockedTime(); if (bt > 0) blockedMs += bt;
			long wt = ti.getWaitedTime();  if (wt > 0) waitedMs  += wt;
		}
		emitG(sb, "sag_is_jvm_thread_state_new_count", "The number of NEW threads", hostLbl, sNew);
		emitG(sb, "sag_is_jvm_thread_state_runnable_count", "The number of RUNNABLE threads", hostLbl, sRunnable);
		emitG(sb, "sag_is_jvm_thread_state_blocked_count", "The number of BLOCKED threads", hostLbl, sBlocked);
		emitG(sb, "sag_is_jvm_thread_state_waiting_count", "The number of WAITING threads without a timeout", hostLbl, sWaiting);
		emitG(sb, "sag_is_jvm_thread_state_timed_waiting_count", "The number of WAITING threads with a timeout", hostLbl, sTimed);
		emitG(sb, "sag_is_jvm_thread_state_terminated_count", "The number of TERMINATED threads", hostLbl, sTerminated);
		emitG(sb, "sag_is_jvm_threads_native_count", "The number of threads in native code", hostLbl, nativeCnt);
		emitG(sb, "sag_is_jvm_threads_suspend_count", "The number of suspended threads", hostLbl, suspendCnt);
		emitG(sb, "sag_is_jvm_threads_blocked_count", "The number of blocked threads", hostLbl, blockedCnt);
		emitG(sb, "sag_is_jvm_threads_waited_count", "The number of waited threads", hostLbl, waitedCnt);
		emitG(sb, "sag_is_jvm_threads_blocked_millis", "Total number of milliseconds that threads have been in a blocked state", hostLbl, blockedMs);
		emitG(sb, "sag_is_jvm_threads_waited_millis", "Total number of milliseconds that threads have waited for a lock", hostLbl, waitedMs);

		// --- OS / process families ---
		java.lang.management.OperatingSystemMXBean osBase = ManagementFactory.getOperatingSystemMXBean();
		emitGd(sb, "sag_is_server_sysload_average", "Number of threads waiting for CPU resources (Linux-only)", hostLbl, osBase.getSystemLoadAverage());
		if (osBase instanceof com.sun.management.OperatingSystemMXBean) {
			com.sun.management.OperatingSystemMXBean os = (com.sun.management.OperatingSystemMXBean) osBase;
			emitG(sb, "sag_is_server_proc_cpu_percent", "0-100 cpu percentage for the IS JVM", hostLbl, (long)(os.getProcessCpuLoad() * 100));
			emitG(sb, "sag_is_server_proc_sys_percent", "0-100 cpu percentage for the OS", hostLbl, (long)(os.getCpuLoad() * 100));
			emitG(sb, "sag_is_server_total_memory_mbytes", "Total physical memory in megabytes", hostLbl, os.getTotalMemorySize() / MB);
			emitG(sb, "sag_is_server_used_memory_mbytes", "Used physical memory in megabytes", hostLbl, (os.getTotalMemorySize() - os.getFreeMemorySize()) / MB);
		}
		if (osBase instanceof com.sun.management.UnixOperatingSystemMXBean) {
			com.sun.management.UnixOperatingSystemMXBean unix = (com.sun.management.UnixOperatingSystemMXBean) osBase;
			emitG(sb, "sag_is_server_open_files_count", "Total used file descriptors (Linux-only)", hostLbl, unix.getOpenFileDescriptorCount());
		}
		File root = new File("/");
		emitG(sb, "sag_is_server_total_disk_mbytes", "Total disk space in megabytes", hostLbl, root.getTotalSpace() / MB);
		emitG(sb, "sag_is_server_used_disk_mbytes", "Used disk space in megabytes", hostLbl, (root.getTotalSpace() - root.getUsableSpace()) / MB);
	}

	// ===== Task 3: server-aggregate families (42) — wm.server.query:getStats (license-free) =====
	// Native sources these same aggregates from getStats via PrometheusStatsProviderImpl, so emitting
	// the raw getStats field value under the sag_is_ name is exact parity by construction.
	static void collectServer(StringBuilder sb, String hostLbl) throws Exception
	{
		IData out = Service.doInvoke("wm.server.query", "getStats", IDataFactory.create());
		srv(sb, out, hostLbl, "serverT", "sag_is_server_threads", "The number of server threads currently in use.");
		srv(sb, out, hostLbl, "serverTMax", "sag_is_server_maxthreads", "The maximum number of server threads defined.");
		srv(sb, out, hostLbl, "maxMem", "sag_is_max_memory_bytes", "The maximum memory for JVM.");
		srv(sb, out, hostLbl, "totalMem", "sag_is_total_memory_bytes", "The total memory for JVM.");
		srv(sb, out, hostLbl, "freeMem", "sag_is_free_memory_bytes", "The total free memory for JVM.");
		srv(sb, out, hostLbl, "usedMem", "sag_is_used_memory_bytes", "The total used memory for JVM.");
		srv(sb, out, hostLbl, "svrT", "sag_is_services", "The total number of running services currently active.");
		srv(sb, out, hostLbl, "svrTMax", "sag_is_max_services", "The highest number of running services that have ever been active concurrently on the server.");
		srv(sb, out, hostLbl, "srvThreadCount", "sag_is_service_threads", "The total number of service threads currently active.");
		srv(sb, out, hostLbl, "srvThreadCountPeak", "sag_is_peak_service_threads", "The highest number of service threads that have ever been active concurrently.");
		srv(sb, out, hostLbl, "sysT", "sag_is_system_threads", "The total number of system threads currently active.");
		srv(sb, out, hostLbl, "sysTMax", "sag_is_max_system_threads", "The highest number of system threads that have ever been active concurrently on the server.");
		srv(sb, out, hostLbl, "conn", "sag_is_number_current_connections", "The total number of sessions currently active.");
		srv(sb, out, hostLbl, "connMax", "sag_is_max_connections", "The highest number of sessions that have ever run concurrently on the server.");
		srv(sb, out, hostLbl, "connAvg", "sag_is_average_connection_time", "The average time per connection.");
		srv(sb, out, hostLbl, "reqTotal", "sag_is_http_requests", "The total number of requests that were completed during the polling interval.");
		srv(sb, out, hostLbl, "reqLifetime", "sag_is_total_http_requests", "The total number of requests that were completed since the server was started.");
		srv(sb, out, hostLbl, "reqAvg", "sag_is_avg_time_per_http_requests", "The average time per HTTP request.");
		srv(sb, out, hostLbl, "newSvcPM", "sag_is_service_starts_per_minute", "The number of Service starts per minute.");
		srv(sb, out, hostLbl, "endSvcPM", "sag_is_service_completions_per_minute", "The number of Service completions per minute.");
		srv(sb, out, hostLbl, "newReqPM", "sag_is_request_starts_per_minute", "The number of Request starts per minute.");
		srv(sb, out, hostLbl, "endReqPM", "sag_is_request_completions_per_minute", "The number of Request completions per minute.");
		srv(sb, out, hostLbl, "errSys", "sag_is_number_nonservice_errors", "The number of non-Service errors.");
		srv(sb, out, hostLbl, "errSvc", "sag_is_number_service_errors", "The number of Service errors.");
		srv(sb, out, hostLbl, "errStartupIS", "sag_is_number_nonservice_startup_errors", "The number of IS startup errors.");
		srv(sb, out, hostLbl, "svcInvokeMetric", "sag_is_number_service_invokes", "The number of Service invokes and errors.");
		srv(sb, out, hostLbl, "startTimeEpoch", "sag_is_server_startup_Time", "The Service startup time (epoch time).");
		srv(sb, out, hostLbl, "errSvcPM", "sag_is_number_service_errors_per_minute", "The number of Service errors in the last minute.");
		srv(sb, out, hostLbl, "errSvcPMwoISInternalSvc", "sag_is_number_service_errors_excluding_internal_svc_per_minute", "The number of Service errors excluding IS Internal services in the last minute.");
		srv(sb, out, hostLbl, "ssnUsed", "sag_is_number_sessions_used", "The number of sessions currently active.");
		srv(sb, out, hostLbl, "ssnPeak", "sag_is_peak_number_sessions", "The peak number of sessions.");
		srv(sb, out, hostLbl, "ssnMax", "sag_is_max_number_sessions_allowed", "The maximum number of HTTP Sessions allowed.");
		srv(sb, out, hostLbl, "connStatefulSessionsCurrent", "sag_is_current_stateful_sessions", "The number of current stateful HTTP Sessions.");
		srv(sb, out, hostLbl, "connStatefulSessionsPeak", "sag_is_peak_stateful_sessions", "The peak number of stateful HTTP Sessions.");
		srv(sb, out, hostLbl, "connStatefulSessionsLimit", "sag_is_stateful_sessions_limit", "The maximum number of stateful HTTP Sessions allowed.");
		srv(sb, out, hostLbl, "reqDur", "sag_is_request_duration", "The total service request time duration for this interval.");
		srv(sb, out, hostLbl, "reqTotDur", "sag_is_total_request_durations", "The total server duration time since last server restart.");
		srv(sb, out, hostLbl, "svcCount", "sag_is_service_count", "The number of services of custom packages loaded.");
		srv(sb, out, hostLbl, "adapterCount", "sag_is_adapter_count", "The number of adapters loaded.");
		srv(sb, out, hostLbl, "packageCount", "sag_is_custom_package_count", "The number of custom packages loaded.");
		srv(sb, out, hostLbl, "systemPackageCount", "sag_is_system_package_count", "The number of system packages loaded.");
		srv(sb, out, hostLbl, "cloudStreamCount", "sag_is_cloudstream_count", "The number of cloud stream connectors loaded.");
	}

	// ===== Task 2: per-service families (9) — wm.server.query:getServiceStats (license-free) =====
	// Each SvcStats record carries the per-service counters; record "name" is already the native
	// uppercase service label (e.g. JC.TOOLS.PUB.LIST:CONVERTTOSTRING). Samples are grouped by
	// family (header once, then one line per service) so the exposition is valid Prometheus.
	static void collectServiceStats(StringBuilder sb, String hostLbl) throws Exception
	{
		IData out = Service.doInvoke("wm.server.query", "getServiceStats", IDataFactory.create());
		IDataCursor c = out.getCursor();
		IData[] recs = IDataUtil.getIDataArray(c, "SvcStats");
		c.destroy();
		if (recs == null) return;
		svcFamily(sb, recs, hostLbl, "sag_is_service_number_access", "The number of times that the service has executed since the server was last started.", "sAccessTotal");
		svcFamily(sb, recs, hostLbl, "sag_is_service_number_running", "The number of service is executing on the server at this instance.", "sRunning");
		svcFamily(sb, recs, hostLbl, "sag_is_service_number_cache_hit", "The total number of times that a cached result for this service has been accessed (hit).", "cHitTotal");
		svcFamily(sb, recs, hostLbl, "sag_is_service_cache_hit_ratio", "The percentage of service requests that have been fulfilled by retrieving the results from cache.", "cHitRatio");
		svcFamily(sb, recs, hostLbl, "sag_is_service_cache_entries", "The number of active cache entries for the service.", "cEntries");
		svcFamily(sb, recs, hostLbl, "sag_is_service_cache_expires", "The number of expired cache entries for the service.", "cExpires");
		svcFamily(sb, recs, hostLbl, "sag_is_service_number_prefetch", "The total number of times the server has prefetched and cached the results for the service.", "cPrefetchTotal");
		svcFamily(sb, recs, hostLbl, "sag_is_service_number_recent_prefetch", "The total number of times the server has prefetched and cached the results for the service in the last poll interval (10 mins default)", "cPrefetched");
		svcFamily(sb, recs, hostLbl, "sag_is_service_number_errors", "The total number of errors for the service.", "cSvcErrors");
	}

	// emit one per-service family: HELP/TYPE once, then a line per service (empty/&nbsp; stats -> 0)
	static void svcFamily(StringBuilder sb, IData[] recs, String hostLbl, String name, String help, String field)
	{
		header(sb, name, help, "gauge");
		for (IData rec : recs) {
			if (rec == null) continue;
			IDataCursor rc = rec.getCursor();
			String svc = IDataUtil.getString(rc, "name");
			String v   = IDataUtil.getString(rc, field);
			rc.destroy();
			if (svc == null) continue;
			line(sb, name, "service=\"" + svc + "\"," + hostLbl, statVal(v));
		}
	}

	// webMethods stats use "&nbsp;" (and blanks) as the empty placeholder; native renders those as 0
	static String statVal(String v)
	{
		if (v == null) return "0";
		v = v.trim();
		if (v.isEmpty() || v.equals("&nbsp;") || v.equals(" ")) return "0";
		return v;
	}

	// read one scalar field from a getStats IData and emit it as a gauge family (skip if absent)
	static void srv(StringBuilder sb, IData out, String hostLbl, String field, String name, String help)
	{
		IDataCursor c = out.getCursor();
		String v = IDataUtil.getString(c, field);
		c.destroy();
		if (v == null) return;
		header(sb, name, help, "gauge");
		line(sb, name, hostLbl, v);
	}

	static String hostname()
	{
		try { return InetAddress.getLocalHost().getHostName(); }
		catch (Exception e) { return "unknown"; }
	}

	// HELP+TYPE header (once per family)
	static void header(StringBuilder sb, String name, String help, String type)
	{
		sb.append("# HELP ").append(name).append(' ').append(help).append('\n');
		sb.append("# TYPE ").append(name).append(' ').append(type).append('\n');
	}

	// a single data line: name{labels} value   (no trailing timestamp — Prometheus stamps at scrape)
	static void line(StringBuilder sb, String name, String labels, Object value)
	{
		sb.append(name).append('{').append(labels).append("} ").append(value).append('\n');
	}

	// convenience: gauge family with a single host-labelled long value
	static void emitG(StringBuilder sb, String name, String help, String hostLbl, long value)
	{
		header(sb, name, help, "gauge");
		line(sb, name, hostLbl, value);
	}

	// convenience: gauge family with a single host-labelled double value
	static void emitGd(StringBuilder sb, String name, String help, String hostLbl, double value)
	{
		header(sb, name, help, "gauge");
		line(sb, name, hostLbl, value);
	}

	// native label-value encoding: space -> _space_, '-' -> _dash_, other non-alnum -> _
	static String enc(String s)
	{
		if (s == null) return "";
		StringBuilder b = new StringBuilder(s.length() + 8);
		for (int i = 0; i < s.length(); i++) {
			char ch = s.charAt(i);
			if (ch == ' ') b.append("_space_");
			else if (ch == '-') b.append("_dash_");
			else if (Character.isLetterOrDigit(ch)) b.append(ch);
			else b.append('_');
		}
		return b.toString();
	}

	static void writeResponse(String body) throws ServiceException
	{
		IData in = IDataFactory.create();
		IDataCursor c = in.getCursor();
		IDataUtil.put(c, "string", body);
		IDataUtil.put(c, "contentType", "text/plain; version=0.0.4; charset=utf-8");
		c.destroy();
		try { Service.doInvoke("pub.flow", "setResponse", in); }
		catch (Exception e) { throw new ServiceException(e); }
	}

	// --- <<IS-END-SHARED>> ---
}
