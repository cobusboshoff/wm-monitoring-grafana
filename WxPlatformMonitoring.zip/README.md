# WxPlatformMonitoring

Provides basic services for Integration Server metrics.

## Related Work

* [WxPrometheus](https://github.com/IBM/WxPrometheus)
* [WxPlatformInsight](https://github.com/IBM/WxPlatformInsight)

## Dependencies 

There are no dependent packages.

## Version History

### v1.0

Initial release.

### v2.0.0

wM `10.15` version support.

### v2.0.1

Change some loggers to default logger.

### v2.0.2

Remove Log4J unwanted trace logging.

### v2.2

Same version as `2.0.2`. Switch version numbering from 3 digits `2.0.2` to 2 digits `2.2`.

### v2.3

Service `getCurrentlyRunningServices` ignores services of `Wx.` packages.

### v2.4

Solves NPE in service `getCurrentlyRunningServices`. The IS log is flooding with error messages ...

```
WxPrometheus: Exception occurred when invoking registered metrics service: java.lang.NullPointerException: Cannot invoke "com.wm.app.b2b.server.BaseService.getPackage()" because "bs" is null
```

## Disclaimer

### IBM Public Repository Disclosure

All content in these repositories including code has been provided by IBM under the associated open source software license and IBM is under no obligation to provide enhancements, updates, or support. IBM developers produced this code as an open source project (not as an IBM product), and IBM makes no assertions as to the level of quality nor security, and will not be maintaining this code going forward.
