<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">registerPropertyResolver</value>
  <array name="sig" type="value" depth="1">
    <value>[i] field:0:required resolverServiceFqn</value>
    <value>[o] field:0:required success</value>
  </array>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gcGlwZWxpbmUNCklEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vy
c29yKCk7DQpTdHJpbmcJcmVzb2x2ZXJTZXJ2aWNlRnFuID0gSURhdGFVdGlsLmdldFN0cmluZygg
cGlwZWxpbmVDdXJzb3IsICJyZXNvbHZlclNlcnZpY2VGcW4iICk7DQpwaXBlbGluZUN1cnNvci5k
ZXN0cm95KCk7DQpTdHJpbmcgc3VjY2VzcyA9ICJmYWxzZSI7DQppZiggcmVzb2x2ZXJTZXJ2aWNl
RnFuID09IG51bGwgKSB7DQoJdGhyb3cgbmV3IFNlcnZpY2VFeGNlcHRpb24oIlByb3ZpZGUgYSBy
ZXNvbHZlciBzZXJ2aWNlLiIpOw0KfQ0KDQp0cnkgew0KCWNvbS5zb2Z0d2FyZWFnLnd4LnBsYXRm
b3JtTW9uaXRvcmluZy5wcm9wZXJ0eVJlc29sdmVyLlByb3BlcnR5UmVzb2x2ZXIucmVnaXN0ZXJS
ZXNvbHZlclNlcnZpY2UocmVzb2x2ZXJTZXJ2aWNlRnFuKTsNCglzdWNjZXNzID0gInRydWUiOw0K
fSBjYXRjaChJbnZhbGlkTmFtZUV4Y2VwdGlvbiBpbmUpICB7DQoJdGhyb3cgbmV3IFNlcnZpY2VF
eGNlcHRpb24oIkludmFsaWQgcmVzb2x2ZXIgc2VydmljZSAnIiArIHJlc29sdmVyU2VydmljZUZx
biArICInOiAiICArDQogaW5lKTsNCn0NCklEYXRhVXRpbC5wdXQocGlwZWxpbmVDdXJzb3IsICJz
dWNjZXNzIiwgc3VjY2Vzcyk7DQpwaXBlbGluZUN1cnNvci5kZXN0cm95KCk7DQo=</value>
</Values>
