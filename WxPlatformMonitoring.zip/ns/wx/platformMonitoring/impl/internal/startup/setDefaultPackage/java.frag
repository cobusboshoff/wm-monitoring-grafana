<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">setDefaultPackage</value>
  <array name="sig" type="value" depth="1">
    <value>[i] field:0:required packageName</value>
  </array>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">U3RyaW5nIHBhY2thZ2VOYW1lID0gSURhdGFVdGlsLmdldFN0cmluZyhwaXBlbGluZS5nZXRDdXJz
b3IoKSwgInBhY2thZ2VOYW1lIik7DQpTeXN0ZW0uZ2V0UHJvcGVydGllcygpLnB1dCgid2F0dC5z
ZXJ2ZXIuZGVmYXVsdFBhY2thZ2UiLCBwYWNrYWdlTmFtZSk7CQ0KdHJ5IHsNCgljb20ud20uYXBw
LmIyYi5zZXJ2ZXIuU2VydmVyLnNhdmVDb25maWd1cmF0aW9uKCk7DQp9IGNhdGNoIChqYXZhLmlv
LklPRXhjZXB0aW9uIGlvKSB7IA0KCS8vIGlucHV0DQoJSURhdGEgaW5wdXQgPSBJRGF0YUZhY3Rv
cnkuY3JlYXRlKCk7DQoJSURhdGFDdXJzb3IgaW5wdXRDdXJzb3IgPSBpbnB1dC5nZXRDdXJzb3Io
KTsNCglJRGF0YVV0aWwucHV0KCBpbnB1dEN1cnNvciwgImxvZ01lc3NhZ2UiLCAiRXJyb3Igd2hl
biByZWdpc3RlcmluZyBkZWZhdWx0IHBhY2thZ2UgIiArIHBhY2thZ2VOYW1lICsgIiB3aXRoIElT
IHNlcnZlciBleHRlbmRlZCBzZXR0aW5nczogIiAgKyBpbyApOw0KCUlEYXRhVXRpbC5wdXQoIGlu
cHV0Q3Vyc29yLCAic2V2ZXJpdHkiLCAiZXJyb3IiICk7DQoJaW5wdXRDdXJzb3IuZGVzdHJveSgp
Ow0KCXRyeXsNCgkJU2VydmljZS5kb0ludm9rZSggInd4LnBsYXRmb3JtTW9uaXRvcmluZy5pbXBs
LnV0aWxpdHkubG9nZ2luZyIsICJsb2dNZXNzYWdlIiwgaW5wdXQgKTsNCgl9Y2F0Y2goIEV4Y2Vw
dGlvbiBlKXsNCgkJU3lzdGVtLm91dC5wcmludGxuKCJlcnJvciB3aGVuIGxvZ2dpbmcgZXJyb3Ig
bWVzc2FnZTogIiArIGUpOw0KCQkNCgl9DQp9DQoJDQo=</value>
</Values>
