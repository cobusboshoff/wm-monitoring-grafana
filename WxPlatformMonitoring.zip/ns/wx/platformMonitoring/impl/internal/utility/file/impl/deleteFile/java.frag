<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">deleteFile</value>
  <array name="sig" type="value" depth="1">
    <value>[i] field:0:required filename</value>
    <value>[i] field:0:optional context</value>
    <value>[i] field:0:required dir</value>
    <value>[o] field:0:required deleted {"false","true"}</value>
  </array>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gcGlwZWxpbmUNCklEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vy
c29yKCk7DQpTdHJpbmcJZmlsZW5hbWUgPSBJRGF0YVV0aWwuZ2V0U3RyaW5nKCBwaXBlbGluZUN1
cnNvciwgImZpbGVuYW1lIiApOw0KU3RyaW5nCWNvbnRleHQgPSBJRGF0YVV0aWwuZ2V0U3RyaW5n
KCBwaXBlbGluZUN1cnNvciwgImNvbnRleHQiICk7DQpTdHJpbmcJZGlyID0gSURhdGFVdGlsLmdl
dFN0cmluZyggcGlwZWxpbmVDdXJzb3IsICJkaXIiICk7DQpwaXBlbGluZUN1cnNvci5kZXN0cm95
KCk7DQoNCmlmKCBmaWxlbmFtZSA9PSBudWxsICkgew0KCXRocm93IG5ldyBTZXJ2aWNlRXhjZXB0
aW9uKCJGaWxlbmFtZSBtdXN0IGJlIHByb3ZpZGVkLiIpOw0KfQ0KaWYoIGNvbnRleHQgPT0gbnVs
bCApIHsNCgljb250ZXh0ID0gImRlZmF1bHQiOw0KfQ0KaWYoIGRpciA9PSBudWxsICkgew0KCXRo
cm93IG5ldyBTZXJ2aWNlRXhjZXB0aW9uKCJEaXJlY3RvcnkgbXVzdCBiZSBwcm92aWRlZC4iKTsN
Cn0NCg0KRmlsZSBiYXNlRGlyID0gbmV3IEZpbGUoZGlyKTsNCmlmKCBiYXNlRGlyLmV4aXN0cygp
ICYmICFiYXNlRGlyLmlzRGlyZWN0b3J5KCkgKSB7DQoJdGhyb3cgbmV3IFNlcnZpY2VFeGNlcHRp
b24oIlByb3ZpZGUgYSB2YWxpZCBkaXJlY3Rvcnkgd2hpY2ggZXhpc3RzLiIpOw0KfSBlbHNlIGlm
KCAhYmFzZURpci5leGlzdHMoKSApIHsNCgliYXNlRGlyLm1rZGlyKCk7DQp9DQoNCkZpbGUgY29u
dGV4dERpciA9IG5ldyBGaWxlKGJhc2VEaXIsIGNvbnRleHQpOw0KaWYoICFjb250ZXh0RGlyLmV4
aXN0cygpICkgew0KCWNvbnRleHREaXIubWtkaXIoKTsNCn0NCg0KU3RyaW5nIGRlbGV0ZWQgPSAi
ZmFsc2UiOw0KRmlsZSB0YXJnZXRGaWxlID0gbmV3IEZpbGUoY29udGV4dERpciwgZmlsZW5hbWUp
Ow0KaWYoIHRhcmdldEZpbGUuZXhpc3RzKCkgKSB7DQoJdGFyZ2V0RmlsZS5kZWxldGUoKTsNCglk
ZWxldGVkID0gInRydWUiOw0KfQ0KDQpJRGF0YUN1cnNvciBwaXBlbGluZUN1cnNvcl8xID0gcGlw
ZWxpbmUuZ2V0Q3Vyc29yKCk7DQpJRGF0YVV0aWwucHV0KCBwaXBlbGluZUN1cnNvcl8xLCAiZGVs
ZXRlZCIsIGRlbGV0ZWQgKTsNCnBpcGVsaW5lQ3Vyc29yXzEuZGVzdHJveSgpOwkJCQ0K</value>
</Values>
