<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">touchFile</value>
  <array name="sig" type="value" depth="1">
    <value>[i] field:0:required filename</value>
    <value>[i] field:0:optional context</value>
    <value>[i] field:0:required dir</value>
  </array>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gcGlwZWxpbmUNCklEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vy
c29yKCk7DQpTdHJpbmcJZmlsZW5hbWUgPSBJRGF0YVV0aWwuZ2V0U3RyaW5nKCBwaXBlbGluZUN1
cnNvciwgImZpbGVuYW1lIiApOw0KU3RyaW5nCWNvbnRleHQgPSBJRGF0YVV0aWwuZ2V0U3RyaW5n
KCBwaXBlbGluZUN1cnNvciwgImNvbnRleHQiICk7DQpTdHJpbmcJZGlyID0gSURhdGFVdGlsLmdl
dFN0cmluZyggcGlwZWxpbmVDdXJzb3IsICJkaXIiICk7DQpwaXBlbGluZUN1cnNvci5kZXN0cm95
KCk7DQoNCmlmKCBmaWxlbmFtZSA9PSBudWxsIHx8IGRpciA9PSBudWxsICkgew0KCXRocm93IG5l
dyBTZXJ2aWNlRXhjZXB0aW9uKCJCb3RoIGZpbGVuYW1lIGFuZCBkaXJlY3RvcnkgbXVzdCBiZSBw
cm92aWRlZC4iKTsNCn0NCmlmKCBjb250ZXh0ID09IG51bGwgKSB7DQoJY29udGV4dCA9ICJkZWZh
dWx0IjsNCn0NCg0KRmlsZSB0YXJnZXRGaWxlID0gbmV3IEZpbGUoZGlyLCBjb250ZXh0ICsgIi8i
ICsgZmlsZW5hbWUpOw0KaWYoICF0YXJnZXRGaWxlLmV4aXN0cygpICkgew0KCXRyeSB7DQoJCS8v
IGZpcnN0IGNyZWF0ZSBhbGwgcmVsZXZhbnQgZGlyZWN0b3JpZXMNCgkJbmV3IEZpbGUoZGlyLCBj
b250ZXh0KS5ta2RpcnMoKTsNCgkJLy8gbm93IGNyZWF0ZSB0aGUgbmV3IGZpbGUNCgkJdGFyZ2V0
RmlsZS5jcmVhdGVOZXdGaWxlKCk7DQoJfSBjYXRjaCAoSU9FeGNlcHRpb24gZSkgew0KCQl0aHJv
dyBuZXcgU2VydmljZUV4Y2VwdGlvbigiRXJyb3Igd2hlbiBjcmVhdGluZyBmaWxlIHdpdGggbmFt
ZSAnIiArIGZpbGVuYW1lICsgIicgaW4gY29udGV4dCAnIiArIGNvbnRleHQgKyAiJzogIiArIGUp
Ow0KCX0NCn0NCi8vIHNldCB0aGUgbW9kaWZpY2F0aW9uIGRhdGUgdG8gbm93IA0KdGFyZ2V0Rmls
ZS5zZXRMYXN0TW9kaWZpZWQoU3lzdGVtLmN1cnJlbnRUaW1lTWlsbGlzKCkpOw0KCQ0K</value>
</Values>
