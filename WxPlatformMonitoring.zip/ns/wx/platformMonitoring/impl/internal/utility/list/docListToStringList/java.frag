<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">docListToStringList</value>
  <array name="sig" type="value" depth="1">
    <value>[i] record:1:required docList</value>
    <value>[i] field:0:required fieldName</value>
    <value>[o] field:1:required stringList</value>
  </array>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgcGlwZWxpbmVDdXJzb3IgPSBwaXBlbGluZS5nZXRDdXJzb3IoKTsNClN0cmlu
ZwlmaWVsZE5hbWUgPSBJRGF0YVV0aWwuZ2V0U3RyaW5nKCBwaXBlbGluZUN1cnNvciwgImZpZWxk
TmFtZSIgKTsNCklEYXRhW10JZG9jTGlzdCA9IElEYXRhVXRpbC5nZXRJRGF0YUFycmF5KCBwaXBl
bGluZUN1cnNvciwgImRvY0xpc3QiICk7DQpqYXZhLnV0aWwuTGlzdDxTdHJpbmc+IHRtcExpc3Qg
PSBuZXcgamF2YS51dGlsLkFycmF5TGlzdDxTdHJpbmc+KCk7DQppZiAoIGRvY0xpc3QgIT0gbnVs
bCkgew0KCWZvciAoIGludCBpID0gMDsgaSA8IGRvY0xpc3QubGVuZ3RoOyBpKysgKSB7DQoJCVN0
cmluZyBmaWVsZCA9IElEYXRhVXRpbC5nZXRTdHJpbmcoZG9jTGlzdFtpXS5nZXRDdXJzb3IoKSwg
ZmllbGROYW1lKTsNCgkJaWYoIGZpZWxkICE9IG51bGwgJiYgISgiIi5lcXVhbHMoZmllbGQpKSAp
IHsNCgkJCXRtcExpc3QuYWRkKGZpZWxkKTsNCgkJfQ0KCX0NCn0NCmlmKCB0bXBMaXN0LnNpemUo
KSA9PSAwICkgew0KCXJldHVybjsNCn0NCklEYXRhVXRpbC5wdXQoIHBpcGVsaW5lQ3Vyc29yLCAi
c3RyaW5nTGlzdCIsIHRtcExpc3QudG9BcnJheShuZXcgU3RyaW5nWzBdKSk7DQpwaXBlbGluZUN1
cnNvci5kZXN0cm95KCk7DQoJDQo=</value>
</Values>
