<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">filterDuplicates</value>
  <array name="sig" type="value" depth="1">
    <value>[i] record:1:required docList</value>
    <value>[i] field:0:required duplicateKey</value>
    <value>[o] record:1:required docList</value>
  </array>
  <value name="subtype">unknown</value>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gcGlwZWxpbmUNCklEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vy
c29yKCk7DQpJRGF0YVtdICAgICAgIGRvY0xpc3QgPSBJRGF0YVV0aWwuZ2V0SURhdGFBcnJheSgg
cGlwZWxpbmVDdXJzb3IsICJkb2NMaXN0IiApOw0KU3RyaW5nICAgICAgICAgICAgICAgZHVwbGlj
YXRlS2V5ID0gSURhdGFVdGlsLmdldFN0cmluZyggcGlwZWxpbmVDdXJzb3IsICJkdXBsaWNhdGVL
ZXkiICk7DQoNCmlmKCBkb2NMaXN0ID09IG51bGwgKSB7DQoJcmV0dXJuOw0KfQ0KDQpqYXZhLnV0
aWwuTWFwPFN0cmluZywgSURhdGE+IGtleU1hcCA9IG5ldyBqYXZhLnV0aWwuSGFzaE1hcDxTdHJp
bmcsIElEYXRhPigpOw0KDQpmb3IoIElEYXRhIGRvYyA6IGRvY0xpc3QgKSB7DQoJaWYoIGRvYyA9
PSBudWxsICkgew0KCQljb250aW51ZTsNCgl9DQoJU3RyaW5nIGRvY1ZhbHVlID0gSURhdGFVdGls
LmdldFN0cmluZyhkb2MuZ2V0Q3Vyc29yKCksIGR1cGxpY2F0ZUtleSk7DQoJaWYoIGRvY1ZhbHVl
ID09IG51bGwgKSB7DQoJCWNvbnRpbnVlOw0KCX0NCgkvLyBkdXBsaWNhdGVzIGdldCBmaWx0ZXJl
ZCBpbiB0aGUgaGFzaE1hcCBhdXRvbWF0aWNhbGx5IGJ5IHRoZSBkdXBsaWNhdGVLZXkNCglrZXlN
YXAucHV0KGRvY1ZhbHVlLCBkb2MpOw0KfQ0KSURhdGFVdGlsLnB1dCggcGlwZWxpbmVDdXJzb3Is
ICJkb2NMaXN0Iiwga2V5TWFwLnZhbHVlcygpLnRvQXJyYXkobmV3IElEYXRhWzBdKSApOw0KcGlw
ZWxpbmVDdXJzb3IuZGVzdHJveSgpOw0KCQ0KCQ0KCQ0K</value>
</Values>
