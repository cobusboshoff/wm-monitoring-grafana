# InvZaSbBpAcquisitionModel / CapaIndividual — summary view with entry points (mermaid)

> Generated 2026-08-20 by `tools/mermaid_process.py` from
> `wm/ProcessModel/InvZaSbBpAcquisitionModel/CapaIndividual.process` (baseline `8c87fe4a0`).
> Layout is mermaid-computed — Designer coordinates are not used.
> Internal — contains estate identifiers; do not distribute unsanitised.

| | |
|---|---|
| Steps | 131 (invokes 52, gateways 61) |
| Transitions | 174 |
| Swimlanes (not drawn — see note) | Frontline, Task/Products Splitting, AML Real Time Rating and Screening, Credit, Fraud, CIM - Onboarding, Enable |
| Non-synchronising joins ⚠ | 55 |
| Invoked task/subprocess packages | 6 |

```mermaid
flowchart TD
    ENTRY1[/"🌐 REST: POST …AcquisitionBpm/api/v1/tests  (TEST endpoint — only static caller)"/]:::entry
    ENTRY2["⚙ AcquisitionBpm.utils.v1:publishInitiateAcquisitionProcessDocument"]:::entry
    ENTRY3[("📄 InitiateAcquisitionProcess")]:::entry
    ENTRY1 -.->|"invokes"| ENTRY2
    ENTRY2 -.->|"pub.publish"| ENTRY3
    ENTRY3 -.->|"PRT trigger subscription"| S98
    ENTRY0(["⚠ no static initiator in repo"]):::entry
    ENTRY0 -.-> S52
    S223[["⛓ CreditProcess"]]:::proc
    S192[["🧑‍💼 Capture and Validate"]]:::task
    S451[["⛓ Generate Deal numbers"]]:::proc
    S157[["⛓ EnableProduct"]]:::proc
    S386[["🧑‍💼 OnboardingVerification"]]:::task
    S120[["🧑‍💼 Evaluate Fraud"]]:::task
    S376[["🧑‍💼 Apply Online Initiate"]]:::task
    S52(["Start Acquisition"]):::startEv
    S178(["End: Process completed"]):::endEv
    S131[["🧑‍💼 Client and Product Verification"]]:::task
    S202[["🧑‍💼 Prepare For Credit"]]:::task
    S258[["⛓ EnableTransaction"]]:::proc
    S98(["Start from document"]):::startEv
    S120 -->|"via 8"| S131
    S120 -->|"via 7"| S157
    S120 -->|"taskOUtputStatus = CompleteProcess (via 10)"| S178
    S120 -->|"via 17"| S192
    S120 -->|"via 9"| S258
    S120 -->|"via 6"| S386
    S131 -->|"back to onboarding team (via 18)"| S131
    S131 -->|"via 6"| S157
    S131 -->|"cancelled at verify; taskOUtputStatus = CompleteProcess (via 12)"| S178
    S131 -->|"via 9"| S192
    S131 -->|"via 8"| S258
    S131 -->|"back to onboarding team (via 16)"| S386
    S157 -->|"back to onboarding team (via 12)"| S131
    S157 -->|"back to onboarding team (via 11)"| S157
    S157 -->|"taskOUtputStatus = CompleteProcess (via 10)"| S178
    S157 -->|"via 10"| S192
    S157 -->|"back to onboarding team (via 13)"| S258
    S157 -->|"back to onboarding team (via 10)"| S386
    S192 -->|"via 20"| S120
    S192 -->|"via 27"| S131
    S192 -->|"via 26"| S157
    S192 -->|"taskOUtputStatus = CompleteProcess (via 33)"| S178
    S192 -->|"via 14"| S192
    S192 -->|"via 19"| S202
    S192 -->|"perFormAmlRating = true (via 11)"| S223
    S192 -->|"via 28"| S258
    S192 -->|"via 15"| S376
    S192 -->|"via 25"| S386
    S192 -->|"via 4"| S451
    S202 -->|"via 15"| S120
    S202 -->|"via 22"| S131
    S202 -->|"via 21"| S157
    S202 -->|"taskOUtputStatus = CompleteProcess (via 28)"| S178
    S202 -->|"via 14"| S192
    S202 -->|"via 14"| S202
    S202 -->|"via 7"| S223
    S202 -->|"via 23"| S258
    S202 -->|"via 10"| S376
    S202 -->|"via 20"| S386
    S223 -->|"taskOUtputStatus = CompleteProcess (via 9)"| S178
    S223 -->|"via 8"| S192
    S223 -->|"via 4"| S202
    S258 -->|"back to onboarding team (via 14)"| S131
    S258 -->|"back to onboarding team (via 13)"| S157
    S258 -->|"taskOUtputStatus = CompleteProcess (via 9)"| S178
    S258 -->|"via 12"| S192
    S258 -->|"back to onboarding team (via 15)"| S258
    S258 -->|"back to onboarding team (via 12)"| S386
    S376 -->|"taskOUtputStatus = CompleteProcess (via 10)"| S178
    S376 -->|"via 8"| S192
    S376 -->|"via 8"| S202
    S386 -->|"back to onboarding team (via 17)"| S131
    S386 -->|"via 5"| S157
    S386 -->|"cancelled at verify; taskOUtputStatus = CompleteProcess (via 11)"| S178
    S386 -->|"via 8"| S192
    S386 -->|"via 7"| S258
    S386 -->|"back to onboarding team (via 15)"| S386
    S451 -->|"via 16"| S120
    S451 -->|"via 23"| S131
    S451 -->|"via 22"| S157
    S451 -->|"taskOUtputStatus = CompleteProcess (via 29)"| S178
    S451 -->|"via 10"| S192
    S451 -->|"via 15"| S202
    S451 -->|"perFormAmlRating = true (via 7)"| S223
    S451 -->|"via 24"| S258
    S451 -->|"via 11"| S376
    S451 -->|"via 21"| S386
    S52 -->|"via 20"| S120
    S52 -->|"via 27"| S131
    S52 -->|"via 26"| S157
    S52 -->|"taskOUtputStatus = CompleteProcess (via 33)"| S178
    S52 -->|"via 19"| S192
    S52 -->|"via 19"| S202
    S52 -->|"via 28"| S258
    S52 -->|"via 15"| S376
    S52 -->|"via 25"| S386
    S98 -->|"via 20"| S120
    S98 -->|"via 27"| S131
    S98 -->|"via 26"| S157
    S98 -->|"taskOUtputStatus = CompleteProcess (via 33)"| S178
    S98 -->|"via 19"| S192
    S98 -->|"via 19"| S202
    S98 -->|"via 28"| S258
    S98 -->|"via 15"| S376
    S98 -->|"via 25"| S386
    classDef entry fill:#fff8e1,stroke:#ff8f00,stroke-width:2px,stroke-dasharray: 6 3
    classDef startEv fill:#d4edda,stroke:#28a745,stroke-width:2px
    classDef endEv fill:#f8d7da,stroke:#dc3545,stroke-width:2px
    classDef gw fill:#fff3cd,stroke:#b8860b
    classDef task fill:#cce5ff,stroke:#004085
    classDef proc fill:#e2d9f3,stroke:#4b0082,stroke-width:2px
    classDef svc fill:#eeeeee,stroke:#666
    classDef errEv fill:#f8d7da,stroke:#dc3545,stroke-dasharray: 4 3
    classDef catch fill:#d1ecf1,stroke:#0c5460
```

**Legend:** rounded = events (⚡ dashed red = error/boundary, ✉ = message catch) · diamond = gateway · 🧑‍💼 double-border = human task (MWS) · ⛓ purple = subprocess/model call · grey = service step · ⚠ = join that does not synchronise its inbound branches (see `3-design-review/parallel-gateway-defects.md`).

**Swimlane note:** summary view: service steps and gateways are contracted into edges; edge labels carry the non-default conditions and elided step counts. **Non-synchronising joins:** `Wait to retry transient map` (And); `Wait to retry determine capture task` (And); `Wait to retry verify transform` (And); `Wait to retry fraud check` (And); `Wait to retry transform pre credit` (And); `Wait to retry Check Product Status` (And); `Wait to retry Product Status Insert` (And); `Wait to retry Update Product Status Post Enable` (And); `Wait to retry Update Product Status after Apply Online` (And); `Wait to retry Update Product Status after Capture Validate` (And); `Wait to retry Update Product Status after Prepare for Credit` (And); `Wait to retry Update Transaction Status` (And); `Wait to retry Update Product Status on Terminate` (And); `Wait to retry Update Product Status` (And); `Map transient data` (UnsynchronizedOr); `Determine Capture Task Required` (UnsynchronizedOr); `Fraud Check` (UnsynchronizedOr); `Credit Required` (UnsynchronizedOr); `Task Queue Info For Capture` (UnsynchronizedOr); `Transform for verify` (UnsynchronizedOr); `Transform data pre credit` (UnsynchronizedOr); `Enable Transaction Required` (UnsynchronizedOr); `Insert Product Status` (UnsynchronizedOr); `Update Product Status Post Enable` (UnsynchronizedOr); `Update Product Status after Apply Online` (UnsynchronizedOr); `Update Product Status after Capture Validate` (UnsynchronizedOr); `Update Product Status after Prepare for Credit` (UnsynchronizedOr); `Update Transaction Status` (UnsynchronizedOr); `Update Product Status on Terminate` (UnsynchronizedOr); `Update Product Status Credit Limit` (UnsynchronizedOr); `Go to capture and validate` (UnsynchronizedOr); `Go to pre credit` (UnsynchronizedOr); `Continue to end` (UnsynchronizedOr); `Start` (UnsynchronizedOr); `Continue to verify` (UnsynchronizedOr); `Return to banker` (UnsynchronizedOr); `Verify required end` (UnsynchronizedOr); `Start enable` (And); `End enable` (And); `End enable transaction` (UnsynchronizedOr); `Capture Complete` (UnsynchronizedOr); `final gateway` (UnsynchronizedOr); `updateTask` (UnsynchronizedOr); `Banker Terminate` (UnsynchronizedOr); `verifyDone` (UnsynchronizedOr); `join from CV and Prepare` (UnsynchronizedOr); `Merge Gateway` (UnsynchronizedOr); `isComplete` (UnsynchronizedOr); `Join To Capture and Validate` (UnsynchronizedOr); `Join to Determine Capture Task Required` (UnsynchronizedOr); `Join before End` (UnsynchronizedOr); `Update Product Status on Terminate successful` (UnsynchronizedOr); `Continue to Determine Task Route` (UnsynchronizedOr); `Send To CaptureAndValidate` (UnsynchronizedOr); `Merge Status With Gateway` (UnsynchronizedOr).

**Task/subprocess containers invoked:** `InvZaSbTpApplyOnline`, `InvZaSbTpCAPAVerification`, `InvZaSbTpCaptureValidate`, `InvZaSbTpEvaluateFraud`, `InvZaSbTpOnboarding`, `InvZaSbTpPrepareForCredit`
