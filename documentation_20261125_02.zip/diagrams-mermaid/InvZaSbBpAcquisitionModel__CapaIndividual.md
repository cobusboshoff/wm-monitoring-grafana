# InvZaSbBpAcquisitionModel / CapaIndividual — process flow with entry points (mermaid)

> Generated 2026-08-20 by `tools/mermaid_process.py` from
> `wm/ProcessModel/InvZaSbBpAcquisitionModel/CapaIndividual.process` (baseline `8c87fe4a0`).
> Layout is mermaid-computed — Designer coordinates are not used.
> Internal — contains estate identifiers; do not distribute unsanitised.

| | |
|---|---|
| Steps | 131 (invokes 52, gateways 61) |
| Transitions | 174 |
| Swimlanes (not drawn — see note) | Frontline, Task/Products Splitting, AML Real Time Rating and Screening, Credit, Fraud, CIM - Onboarding, Enable |
| Non-synchronising joins ⚠ | 55 |
| Invoked task/subprocess packages | 6 |

```mermaid
flowchart TD
    ENTRY1[/"🌐 REST: POST …AcquisitionBpm/api/v1/tests  (TEST endpoint — only static caller)"/]:::entry
    ENTRY2["⚙ AcquisitionBpm.utils.v1:publishInitiateAcquisitionProcessDocument"]:::entry
    ENTRY3[("📄 InitiateAcquisitionProcess")]:::entry
    ENTRY1 -.->|"invokes"| ENTRY2
    ENTRY2 -.->|"pub.publish"| ENTRY3
    ENTRY3 -.->|"PRT trigger subscription"| S98
    ENTRY0(["⚠ no static initiator in repo"]):::entry
    ENTRY0 -.-> S52
    S22(["✉ Wait to retry transient map ⚠And"]):::catch
    S38(["✉ Wait to retry determine capture task ⚠And"]):::catch
    S98(["Start from document"]):::startEv
    S109(["✉ Wait to retry capture task queue info"]):::catch
    S136(["✉ «CIM - Onboarding» Wait to retry verify transform ⚠And"]):::catch
    S142(["✉ «Fraud» Wait to retry fraud check ⚠And"]):::catch
    S229(["✉ Wait to retry transform pre credit ⚠And"]):::catch
    S468(["✉ «CIM - Onboarding» Wait to retry Check Product Status ⚠And"]):::catch
    S513(["✉ Wait to retry Product Status Insert ⚠And"]):::catch
    S525(["✉ «Enable» Wait to retry Update Product Status Post Enable ⚠And"]):::catch
    S535(["✉ Wait to retry Update Product Status after Apply Online ⚠And"]):::catch
    S544(["✉ Wait to retry Update Product Status after Capture Validate ⚠And"]):::catch
    S550(["✉ Wait to retry Update Product Status after Prepare for Credit ⚠And"]):::catch
    S559(["✉ «Enable» Wait to retry Update Transaction Status ⚠And"]):::catch
    S584(["✉ Wait to retry Update Product Status on Terminate ⚠And"]):::catch
    S616(["✉ «Credit» Wait to retry Update Product Status ⚠And"]):::catch
    S12["Map transient data ⚠UnsynchronizedOr"]:::svc
    S26["Create Acquisition Process Document"]:::svc
    S29["Determine Capture Task Required ⚠UnsynchronizedOr"]:::svc
    S49["«Fraud» Fraud Check ⚠UnsynchronizedOr"]:::svc
    S54["Credit Required ⚠UnsynchronizedOr"]:::svc
    S103["Task Queue Info For Capture ⚠UnsynchronizedOr"]:::svc
    S115["«Fraud» Determine Fraud Task Required"]:::svc
    S120[["🧑‍💼 «Fraud» Evaluate Fraud"]]:::task
    S127["«CIM - Onboarding» Transform for verify ⚠UnsynchronizedOr"]:::svc
    S131[["🧑‍💼 «CIM - Onboarding» Client and Product Verification"]]:::task
    S133["«CIM - Onboarding» Transform Post Verify"]:::svc
    S155["«Enable» enrichDataForEnableProduct"]:::svc
    S157[["⛓ «Enable» EnableProduct"]]:::proc
    S159["«Enable» Post Enable"]:::svc
    S192[["🧑‍💼 Capture and Validate"]]:::task
    S197["Transform data pre credit ⚠UnsynchronizedOr"]:::svc
    S202[["🧑‍💼 Prepare For Credit"]]:::task
    S223[["⛓ «AML Real Time Rating and Screening» CreditProcess"]]:::proc
    S242["«CIM - Onboarding» Determine Verify Required"]:::svc
    S256["«Enable» Enable Transaction Required ⚠UnsynchronizedOr"]:::svc
    S257["«Enable» Transform data for EnableTransaction"]:::svc
    S258[["⛓ «Enable» EnableTransaction"]]:::proc
    S271["«Enable» Initiate Upload Documents"]:::svc
    S276["«AML Real Time Rating and Screening» Perform AML Real Time Rating"]:::svc
    S285["«AML Real Time Rating and Screening» Perform AML Real Time Rating"]:::svc
    S311["Send Message To Parent Process"]:::svc
    S326["captureTaskForTravelCurrency"]:::svc
    S376[["🧑‍💼 Apply Online Initiate"]]:::task
    S381["transformDataApplyOnline"]:::svc
    S385["«CIM - Onboarding» useNewOnboardingTaskCheck"]:::svc
    S386[["🧑‍💼 «CIM - Onboarding» OnboardingVerification"]]:::task
    S402["«AML Real Time Rating and Screening» Perform AML Real Time Rating"]:::svc
    S417["get Deal Toggle"]:::svc
    S437["apply Online Task Required"]:::svc
    S443["determineTaskRoute"]:::svc
    S451[["⛓ Generate Deal numbers"]]:::proc
    S473["Update Tasksplititng fields"]:::svc
    S478["«CIM - Onboarding» Roll Products Task Splitting Changes Back"]:::svc
    S508["Insert Product Status ⚠UnsynchronizedOr"]:::svc
    S518["«CIM - Onboarding» Check Product Status"]:::svc
    S521["«Enable» Update Product Status Post Enable ⚠UnsynchronizedOr"]:::svc
    S531["Update Product Status after Apply Online ⚠UnsynchronizedOr"]:::svc
    S539["Update Product Status after Capture Validate ⚠UnsynchronizedOr"]:::svc
    S547["Update Product Status after Prepare for Credit ⚠UnsynchronizedOr"]:::svc
    S557["«Enable» Update Transaction Status ⚠UnsynchronizedOr"]:::svc
    S565["«Enable» postEnableTransaction"]:::svc
    S571["«Task/Products Splitting» Determine Active And Non Active Products for Credit"]:::svc
    S574["«Task/Products Splitting» Determine Active And Non Active Products for CaptureValidate"]:::svc
    S577["«Task/Products Splitting» Determine Active And Non Active Products for Onboarding"]:::svc
    S580["Update Product Status on Terminate ⚠UnsynchronizedOr"]:::svc
    S604["«Credit» Credit Limit Single Product Check"]:::svc
    S612["«Credit» Update Product Status Credit Limit ⚠UnsynchronizedOr"]:::svc
    S19{"Transient data map successful"}:::gw
    S32{"Capture task required"}:::gw
    S36{"Determine capture task successful"}:::gw
    S58{"Credit required"}:::gw
    S67{"Go to capture and validate ⚠UnsynchronizedOr"}:::gw
    S72{"Continue to credit"}:::gw
    S80{"«Credit» Credit complete"}:::gw
    S83{"Go to pre credit ⚠UnsynchronizedOr"}:::gw
    S91{"Continue to end ⚠UnsynchronizedOr"}:::gw
    S99{"Start ⚠UnsynchronizedOr"}:::gw
    S106{"Set task queue info successful"}:::gw
    S117{"«Fraud» Fraud required"}:::gw
    S124{"«CIM - Onboarding» Verify required"}:::gw
    S129{"«CIM - Onboarding» Verify transform successful"}:::gw
    S139{"«Fraud» Fraud check successful"}:::gw
    S145{"«Fraud» Fraud approved"}:::gw
    S148{"«CIM - Onboarding» Continue to verify ⚠UnsynchronizedOr"}:::gw
    S152{"«CIM - Onboarding» Verified"}:::gw
    S161{"«Enable» Post enable transition"}:::gw
    S174{"«CIM - Onboarding» Return to banker ⚠UnsynchronizedOr"}:::gw
    S180{"Banker terminate"}:::gw
    S199{"Credit transform successful"}:::gw
    S245{"«CIM - Onboarding» Verify required end ⚠UnsynchronizedOr"}:::gw
    S250{"«Enable» Start enable ⚠And"}:::gw
    S251{"«Enable» End enable ⚠And"}:::gw
    S259{"«Enable» Start enable transaction"}:::gw
    S260{"«Enable» End enable transaction ⚠UnsynchronizedOr"}:::gw
    S279{"«AML Real Time Rating and Screening» Check AML Real Time Rating status"}:::gw
    S287{"«AML Real Time Rating and Screening» Check AML Real Time Rating status"}:::gw
    S316{"Capture Complete ⚠UnsynchronizedOr"}:::gw
    S328{"Travel currency"}:::gw
    S336{"«Enable» End Travel Currency"}:::gw
    S340{"«Enable» final gateway ⚠UnsynchronizedOr"}:::gw
    S347{"updateTask"}:::gw
    S351{"updateTask ⚠UnsynchronizedOr"}:::gw
    S360{"Banker Terminate ⚠UnsynchronizedOr"}:::gw
    S356{"Apply Online"}:::gw
    S388{"«CIM - Onboarding» verifyDone ⚠UnsynchronizedOr"}:::gw
    S392{"«CIM - Onboarding» useNewTask"}:::gw
    S404{"«AML Real Time Rating and Screening» CheckAmlRealTime"}:::gw
    S410{"«AML Real Time Rating and Screening» join from CV and Prepare ⚠UnsynchronizedOr"}:::gw
    S420{"Fin Update"}:::gw
    S445{"Split Post Capa"}:::gw
    S457{"«CIM - Onboarding» Merge Gateway ⚠UnsynchronizedOr"}:::gw
    S465{"«CIM - Onboarding» isComplete ⚠UnsynchronizedOr"}:::gw
    S492{"«Task/Products Splitting» Join To Capture and Validate ⚠UnsynchronizedOr"}:::gw
    S497{"Join to Determine Capture Task Required ⚠UnsynchronizedOr"}:::gw
    S502{"«Fraud» Join before End ⚠UnsynchronizedOr"}:::gw
    S510{"Check Insert status"}:::gw
    S523{"«Enable» Update Product Status Post Enable Successful"}:::gw
    S533{"Update Product Status after Apply Online Successful"}:::gw
    S541{"Update Product Status after Capture Validate Successful"}:::gw
    S549{"Update Product Status after Prepare for Credit Successful"}:::gw
    S558{"«Enable» Update Transaction Status Successful"}:::gw
    S582{"Update Product Status on Terminate successful ⚠UnsynchronizedOr"}:::gw
    S592{"Continue to Determine Task Route ⚠UnsynchronizedOr"}:::gw
    S598{"«Task/Products Splitting» Send To CaptureAndValidate ⚠UnsynchronizedOr"}:::gw
    S601{"«Task/Products Splitting» Default to CaptureAndValidate"}:::gw
    S606{"«Credit» IsSingle CreditLimit Product"}:::gw
    S609{"«Credit» Merge Status With Gateway ⚠UnsynchronizedOr"}:::gw
    S613{"«Credit» Update Status"}:::gw
    S178(["End: «CIM - Onboarding» Process completed"]):::endEv
    S52(["Start Acquisition"]):::startEv
    S12 --> S19
    S19 -->|"mapTransientDataResponse/serviceHeaderRe…"| S22
    S22 -->|"Join wait time > 5 minutes…"| S12
    S29 --> S36
    S36 -->|"captureTaskRequiredResponse/serviceHeade…"| S38
    S38 -->|"Join wait time > 5 minutes…"| S29
    S54 --> S58
    S36 -->|"Default…"| S32
    S58 -->|"Default…"| S67
    S58 -->|"creditRequiredResponse/creditRequired = …"| S83
    S52 -->|"Default…"| S99
    S99 --> S12
    S98 -->|"Default…"| S99
    S67 -->|"Default…"| S103
    S103 --> S106
    S106 -->|"setTaskQueueInfoForCaptureResponse/servi…"| S109
    S109 -->|"Timeout value not set…"| S103
    S115 --> S117
    S117 -->|"fraudTaskRequiredResponse/fraudTaskRequi…"| S120
    S127 -->|"Default…"| S129
    S129 -->|"Default…"| S131
    S131 --> S133
    S129 -->|"transformDataForVerifyResponse/serviceHe…"| S136
    S136 -->|"Join wait time > 5 minutes…"| S127
    S49 --> S139
    S139 -->|"Default…"| S115
    S139 -->|"fraudCheckResponse/serviceHeaderResponse…"| S142
    S142 -->|"Join wait time > 5 minutes…"| S49
    S120 --> S145
    S117 -->|"Default…"| S148
    S145 -->|"acquisitionProcessDocument/transientData…"| S148
    S155 --> S157
    S157 --> S159
    S161 -->|"back to onboarding team"| S148
    S161 -->|"postEnableResponse/postEnableStep = capt…"| S174
    S180 -->|"acquisitionProcessDocument/transientData…"| S91
    S106 --> S192
    S83 -->|"Default…"| S197
    S197 --> S199
    S199 -->|"Default…"| S202
    S223 --> S80
    S80 -->|"Default…"| S83
    S199 -->|"transformDataPreCreditResponse/serviceHe…"| S229
    S229 -->|"Join wait time > 5 minutes…"| S197
    S148 -->|"Default…"| S242
    S242 --> S124
    S152 -->|"initiateCAPAProcess/commonProcessData/co…"| S245
    S124 -->|"verifyTaskRequiredResponse/verifyTaskReq…"| S245
    S245 --> S250
    S250 --> S155
    S251 --> S161
    S250 --> S256
    S256 --> S259
    S259 -->|"enableTransactionRequiredResponse/enable…"| S257
    S257 --> S258
    S259 -->|"Default…"| S260
    S161 -->|"postEnableResponse/postEnableStep = end…"| S271
    S276 --> S279
    S285 --> S287
    S72 -->|"Default…"| S285
    S287 -->|"Default…"| S83
    S279 -->|"Default…"| S174
    S279 -->|"performAMLRealTimeRatingResponse/service…"| S49
    S91 -->|"Default…"| S311
    S180 -->|"Default…"| S316
    S32 -->|"captureTaskRequiredResponse/captureTaskR…"| S316
    S326 --> S328
    S19 -->|"Default…"| S26
    S328 -->|"travelCurrencyKycCompleted = true…"| S256
    S260 --> S336
    S336 -->|"Default…"| S251
    S271 -->|"Default…"| S340
    S336 -->|"EnableTransactionProcessResponse/transac…"| S340
    S347 -->|"Default…"| S72
    S351 -->|"Default…"| S180
    S356 -->|"isApplyOnlineInitiateRequired = true…"| S381
    S381 --> S376
    S124 -->|"Default…"| S385
    S133 -->|"Default…"| S388
    S388 -->|"Default…"| S152
    S386 -->|"Default…"| S388
    S385 --> S392
    S392 -->|"useNewOnboardingtask = true…"| S386
    S392 -->|"Default…"| S127
    S402 --> S404
    S287 -->|"performAMLRealTimeRatingResponse/service…"| S410
    S410 --> S223
    S404 -->|"perFormAmlRating = true"| S410
    S356 -->|"Default…"| S54
    S360 -->|"Default…"| S54
    S32 -->|"Default…"| S437
    S437 --> S356
    S443 --> S445
    S417 --> S420
    S420 -->|"createDealInFinanceToggle = true…"| S451
    S340 -->|"Default…"| S457
    S465 -->|"taskOUtputStatus = CompleteProcess"| S178
    S465 -->|"Default…"| S468
    S468 -->|"Join wait time > 1 days…"| S457
    S360 -->|"acquisitionProcessDocument/transientData…"| S473
    S473 --> S91
    S152 -->|"initiateCAPAProcess/commonProcessData/co…"| S478
    S478 --> S174
    S72 -->|"acquisitionProcessDocument/transientData…"| S360
    S404 -->|"Default…"| S492
    S174 --> S492
    S492 --> S67
    S328 -->|"Default…"| S497
    S351 -->|"acquisitionProcessDocument/transientData…"| S497
    S347 -->|"acquisitionProcessDocument/transientData…"| S497
    S497 --> S29
    S152 -->|"cancelled at verify"| S502
    S145 -->|"Default…"| S502
    S26 --> S508
    S508 --> S510
    S510 -->|"Default…"| S326
    S510 -->|"insertResponse/serviceHeaderResponse/res…"| S513
    S513 -->|"Join wait time > 5 minutes…"| S508
    S457 --> S518
    S518 --> S465
    S159 --> S521
    S521 --> S523
    S523 -->|"Default…"| S525
    S525 -->|"Join wait time > 5 minutes…"| S521
    S523 -->|"postEnableUpdateResponse/serviceHeaderRe…"| S251
    S376 -->|"Default…"| S531
    S531 --> S533
    S533 -->|"Default…"| S535
    S535 -->|"Join wait time > 5 minutes…"| S531
    S533 -->|"checkBeforeUpdateResponse/serviceHeaderR…"| S360
    S192 -->|"Default…"| S539
    S539 --> S541
    S541 -->|"checkBeforeUpdateResponse/serviceHeaderR…"| S417
    S541 -->|"Default…"| S544
    S544 -->|"Join wait time > 5 minutes…"| S539
    S202 --> S547
    S547 --> S549
    S549 -->|"Default…"| S550
    S550 -->|"Join wait time > 5 minutes…"| S547
    S549 -->|"checkBeforeUpdateResponse/serviceHeaderR…"| S347
    S559 -->|"Join wait time > 5 minutes…"| S557
    S558 -->|"Default…"| S559
    S557 --> S558
    S558 --> S260
    S258 --> S565
    S565 --> S557
    S571 --> S402
    S574 --> S492
    S316 -->|"Default…"| S577
    S577 --> S276
    S502 --> S580
    S580 --> S582
    S582 -->|"Default…"| S584
    S584 -->|"Join wait time > 5 minutes…"| S580
    S582 -->|"updateResponse/serviceHeaderResponse/res…"| S91
    S451 -->|"Default…"| S592
    S420 -->|"Default…"| S592
    S592 -->|"Default…"| S443
    S445 -->|"onboardingRequired/required = true…"| S351
    S445 -->|"creditRequired/required = true…"| S571
    S445 -->|"captureAndValidateRequired/required = tr…"| S598
    S598 --> S574
    S445 -->|"Default…"| S601
    S601 --> S598
    S80 -->|"CreditProcessResponse/creditData/minuteS…"| S604
    S606 -->|"Default…"| S67
    S311 -->|"Default…"| S609
    S609 -->|"Default…"| S457
    S612 --> S613
    S613 -->|"Default…"| S616
    S616 -->|"Join wait time > 5 minutes…"| S612
    S604 --> S612
    S606 -->|"isSingleCreditLimitProduct = true…"| S609
    S613 --> S606
    classDef entry fill:#fff8e1,stroke:#ff8f00,stroke-width:2px,stroke-dasharray: 6 3
    classDef startEv fill:#d4edda,stroke:#28a745,stroke-width:2px
    classDef endEv fill:#f8d7da,stroke:#dc3545,stroke-width:2px
    classDef gw fill:#fff3cd,stroke:#b8860b
    classDef task fill:#cce5ff,stroke:#004085
    classDef proc fill:#e2d9f3,stroke:#4b0082,stroke-width:2px
    classDef svc fill:#eeeeee,stroke:#666
    classDef errEv fill:#f8d7da,stroke:#dc3545,stroke-dasharray: 4 3
    classDef catch fill:#d1ecf1,stroke:#0c5460
```

**Legend:** rounded = events (⚡ dashed red = error/boundary, ✉ = message catch) · diamond = gateway · 🧑‍💼 double-border = human task (MWS) · ⛓ purple = subprocess/model call · grey = service step · ⚠ = join that does not synchronise its inbound branches (see `3-design-review/parallel-gateway-defects.md`).

**Swimlane note:** nodes tagged «lane» sit outside the dominant lane (untagged = Frontline); membership is derived from x-band containment only — lanes are not drawn, layout remains mermaid-computed. **Non-synchronising joins:** `Wait to retry transient map` (And); `Wait to retry determine capture task` (And); `«CIM - Onboarding» Wait to retry verify transform` (And); `«Fraud» Wait to retry fraud check` (And); `Wait to retry transform pre credit` (And); `«CIM - Onboarding» Wait to retry Check Product Status` (And); `Wait to retry Product Status Insert` (And); `«Enable» Wait to retry Update Product Status Post Enable` (And); `Wait to retry Update Product Status after Apply Online` (And); `Wait to retry Update Product Status after Capture Validate` (And); `Wait to retry Update Product Status after Prepare for Credit` (And); `«Enable» Wait to retry Update Transaction Status` (And); `Wait to retry Update Product Status on Terminate` (And); `«Credit» Wait to retry Update Product Status` (And); `Map transient data` (UnsynchronizedOr); `Determine Capture Task Required` (UnsynchronizedOr); `«Fraud» Fraud Check` (UnsynchronizedOr); `Credit Required` (UnsynchronizedOr); `Task Queue Info For Capture` (UnsynchronizedOr); `«CIM - Onboarding» Transform for verify` (UnsynchronizedOr); `Transform data pre credit` (UnsynchronizedOr); `«Enable» Enable Transaction Required` (UnsynchronizedOr); `Insert Product Status` (UnsynchronizedOr); `«Enable» Update Product Status Post Enable` (UnsynchronizedOr); `Update Product Status after Apply Online` (UnsynchronizedOr); `Update Product Status after Capture Validate` (UnsynchronizedOr); `Update Product Status after Prepare for Credit` (UnsynchronizedOr); `«Enable» Update Transaction Status` (UnsynchronizedOr); `Update Product Status on Terminate` (UnsynchronizedOr); `«Credit» Update Product Status Credit Limit` (UnsynchronizedOr); `Go to capture and validate` (UnsynchronizedOr); `Go to pre credit` (UnsynchronizedOr); `Continue to end` (UnsynchronizedOr); `Start` (UnsynchronizedOr); `«CIM - Onboarding» Continue to verify` (UnsynchronizedOr); `«CIM - Onboarding» Return to banker` (UnsynchronizedOr); `«CIM - Onboarding» Verify required end` (UnsynchronizedOr); `«Enable» Start enable` (And); `«Enable» End enable` (And); `«Enable» End enable transaction` (UnsynchronizedOr); `Capture Complete` (UnsynchronizedOr); `«Enable» final gateway` (UnsynchronizedOr); `updateTask` (UnsynchronizedOr); `Banker Terminate` (UnsynchronizedOr); `«CIM - Onboarding» verifyDone` (UnsynchronizedOr); `«AML Real Time Rating and Screening» join from CV and Prepare` (UnsynchronizedOr); `«CIM - Onboarding» Merge Gateway` (UnsynchronizedOr); `«CIM - Onboarding» isComplete` (UnsynchronizedOr); `«Task/Products Splitting» Join To Capture and Validate` (UnsynchronizedOr); `Join to Determine Capture Task Required` (UnsynchronizedOr); `«Fraud» Join before End` (UnsynchronizedOr); `Update Product Status on Terminate successful` (UnsynchronizedOr); `Continue to Determine Task Route` (UnsynchronizedOr); `«Task/Products Splitting» Send To CaptureAndValidate` (UnsynchronizedOr); `«Credit» Merge Status With Gateway` (UnsynchronizedOr).

**Task/subprocess containers invoked:** `InvZaSbTpApplyOnline`, `InvZaSbTpCAPAVerification`, `InvZaSbTpCaptureValidate`, `InvZaSbTpEvaluateFraud`, `InvZaSbTpOnboarding`, `InvZaSbTpPrepareForCredit`
