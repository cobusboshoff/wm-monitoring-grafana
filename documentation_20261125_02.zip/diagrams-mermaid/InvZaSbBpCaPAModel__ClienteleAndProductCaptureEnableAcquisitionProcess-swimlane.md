# InvZaSbBpCaPAModel / ClienteleAndProductCaptureEnableAcquisitionProcess — process flow (mermaid, swimlane)

> Generated 2026-08-20 by `tools/mermaid_process.py` from
> `wm/ProcessModel/InvZaSbBpCaPAModel/ClienteleAndProductCaptureEnableAcquisitionProcess.process` (baseline `8c87fe4a0`).
> Layout is mermaid-computed — Designer coordinates are not used.
> Internal — contains estate identifiers; do not distribute unsanitised.

| | |
|---|---|
| Steps | 41 (invokes 21, gateways 17) |
| Transitions | 52 |
| Swimlanes (drawn) | Frontline Banking Consultant, KYC Consultant, Fraud Investigator |
| Non-synchronising joins ⚠ | 9 |
| Invoked task/subprocess packages | 4 |

```mermaid
swimlane-beta LR
    subgraph lane0["Frontline Banking Consultant"]
        S7(["Start initiateCAPAProcess"])
        S55[["🧑‍💼 Capture and Validate Application ⚠UnsynchronizedOr"]]
        S507["checkBankerValidationRequired"]
        S510{"Bypass Bankerer"}
    end
    subgraph lane1["KYC Consultant"]
        S56[["🧑‍💼 Client and Product Verification"]]
        S76[["🧑‍💼 KYC Approval"]]
        S296["Update KPI for Complete"]
        S301["Update KPI for Terminated ⚠UnsynchronizedOr"]
        S347[["⛓ EnableProduct"]]
        S375["enrichDataForEnableProduct"]
        S380["checkEnablementComplete"]
        S405["sendNotificationToCIM"]
        S408["checkCimVerificationRequired"]
        S419[["⛓ EnableTransaction"]]
        S432["enrichDataFromCaPaToEnableTransaction"]
        S461["checkEnableTransactionComplete"]
        S479["enrichDataFromCompletedCreditToCapa"]
        S477["enrichDataFromCapaToCredit"]
        S482["callCredit"]
        S487[["⛓ CreditProcess"]]
        S501["checkForPendingDeals"]
        S544["Upload Documents"]
        S10{"Kyc Complete"}
        S47{"Capture and Validate Complete? ⚠UnsynchronizedOr"}
        S351{"Enable Complete"}
        S410{"Skip CIM? ⚠UnsynchronizedOr"}
        S414{"Skip CIM join ⚠UnsynchronizedOr"}
        S424{"Everything complete ⚠And"}
        S428{"Transactions and Products"}
        S466{"KYC Approval Required?"}
        S469{"Approval declined?"}
        S483{"Call Credit"}
        S493{"BackToBanker ⚠UnsynchronizedOr"}
        S498{"Complete Process"}
        S503{"Pending Deals?"}
        S20(["End: Request Terminated"])
        S15(["End: Request Completed"])
    end
    subgraph lane2["Fraud Investigator"]
        S333[["🧑‍💼 Refer To Fraud"]]
        S329{"Trigger Fraud? ⚠UnsynchronizedOr"}
        S337{"Fraud Approval"}
        S396{"Gateway1 ⚠UnsynchronizedOr"}
    end
    S55 --> S47
    S47 -->|"Request Terminated"| S301
    S10 -->|"Requests Terminated"| S301
    S301 --> S20
    S329 -->|"Fraud Trigger"| S333
    S333 --> S337
    S337 -->|"Request Terminated"| S301
    S375 --> S347
    S347 --> S380
    S329 -->|"Default…"| S396
    S337 -->|"Default…"| S396
    S405 -->|"Default…"| S396
    S396 -->|"Default…"| S408
    S408 --> S410
    S410 -->|"Default…"| S56
    S410 -->|"checkCimVerificationRequiredResponse/ski…"| S414
    S428 --> S375
    S428 --> S432
    S432 --> S419
    S10 -->|"Rejected"| S55
    S351 -->|"Products Not Enabled"| S405
    S10 -->|"Completed"| S428
    S380 -->|"Default…"| S424
    S424 --> S351
    S414 --> S10
    S419 --> S461
    S461 --> S424
    S56 -->|"Default…"| S466
    S466 -->|"initiateCAPAProcess/commonProcessData/co…"| S76
    S76 --> S469
    S469 -->|"initiateCAPAProcess/commonProcessData/co…"| S410
    S469 -->|"Default…"| S414
    S466 -->|"Default…"| S414
    S47 -->|"Default…"| S482
    S482 --> S483
    S483 -->|"send to credit"| S477
    S477 -->|"Default…"| S487
    S487 -->|"Default…"| S479
    S483 -->|"Do not call Credit"| S329
    S479 -->|"Default…"| S493
    S493 -->|"Default…"| S55
    S501 --> S503
    S503 -->|"Default…"| S498
    S503 -->|"checkForPendingDealsResponse/dealsPendin…"| S493
    S7 --> S507
    S507 --> S510
    S510 -->|"checkBankerValidationRequiredResponse/sk…"| S47
    S510 -->|"Default…"| S55
    S351 --> S501
    S498 -->|"Default…"| S296
    S296 --> S544
    S544 -->|"Default…"| S15
```

**Legend:** rounded = events (⚡ dashed red = error/boundary, ✉ = message catch) · diamond = gateway · 🧑‍💼 double-border = human task (MWS) · ⛓ purple = subprocess/model call · grey = service step · ⚠ = join that does not synchronise its inbound branches (see `3-design-review/parallel-gateway-defects.md`).

**Swimlane note:** lanes are drawn via mermaid swimlane-beta (requires mermaid ≥ 11.16; syntax is beta and colour classes are omitted). Lane membership is derived from x-band containment only — layout remains mermaid-computed. **Non-synchronising joins:** `Capture and Validate Application` (UnsynchronizedOr); `Update KPI for Terminated` (UnsynchronizedOr); `Capture and Validate Complete?` (UnsynchronizedOr); `Trigger Fraud?` (UnsynchronizedOr); `Gateway1` (UnsynchronizedOr); `Skip CIM?` (UnsynchronizedOr); `Skip CIM join` (UnsynchronizedOr); `Everything complete` (And); `BackToBanker` (UnsynchronizedOr).

**Task/subprocess containers invoked:** `InvZaSbTpCAPACaptureValidateApplication`, `InvZaSbTpCAPAKYCStatusOverride`, `InvZaSbTpCAPAVerification`, `InvZaSbTpReferToFraud`
