# InvZaSbBpCaPAModel / ClienteleAndProductCaptureEnableAcquisitionProcess — process flow (mermaid)

> Generated 2026-08-20 by `tools/mermaid_process.py` from
> `wm/ProcessModel/InvZaSbBpCaPAModel/ClienteleAndProductCaptureEnableAcquisitionProcess.process` (baseline `8c87fe4a0`).
> Layout is mermaid-computed — Designer coordinates are not used.
> Internal — contains estate identifiers; do not distribute unsanitised.

| | |
|---|---|
| Steps | 41 (invokes 21, gateways 17) |
| Transitions | 52 |
| Swimlanes (not drawn — see note) | Frontline Banking Consultant, KYC Consultant, Fraud Investigator |
| Non-synchronising joins ⚠ | 9 |
| Invoked task/subprocess packages | 4 |

```mermaid
flowchart TD
    S7(["«Frontline Banking Consultant» Start initiateCAPAProcess"]):::startEv
    S55[["🧑‍💼 «Frontline Banking Consultant» Capture and Validate Application ⚠UnsynchronizedOr"]]:::task
    S56[["🧑‍💼 Client and Product Verification"]]:::task
    S76[["🧑‍💼 KYC Approval"]]:::task
    S296["Update KPI for Complete"]:::svc
    S301["Update KPI for Terminated ⚠UnsynchronizedOr"]:::svc
    S333[["🧑‍💼 «Fraud Investigator» Refer To Fraud"]]:::task
    S347[["⛓ EnableProduct"]]:::proc
    S375["enrichDataForEnableProduct"]:::svc
    S380["checkEnablementComplete"]:::svc
    S405["sendNotificationToCIM"]:::svc
    S408["checkCimVerificationRequired"]:::svc
    S419[["⛓ EnableTransaction"]]:::proc
    S432["enrichDataFromCaPaToEnableTransaction"]:::svc
    S461["checkEnableTransactionComplete"]:::svc
    S479["enrichDataFromCompletedCreditToCapa"]:::svc
    S477["enrichDataFromCapaToCredit"]:::svc
    S482["callCredit"]:::svc
    S487[["⛓ CreditProcess"]]:::proc
    S501["checkForPendingDeals"]:::svc
    S507["«Frontline Banking Consultant» checkBankerValidationRequired"]:::svc
    S544["Upload Documents"]:::svc
    S10{"Kyc Complete"}:::gw
    S47{"Capture and Validate Complete? ⚠UnsynchronizedOr"}:::gw
    S329{"«Fraud Investigator» Trigger Fraud? ⚠UnsynchronizedOr"}:::gw
    S337{"«Fraud Investigator» Fraud Approval"}:::gw
    S351{"Enable Complete"}:::gw
    S396{"«Fraud Investigator» Gateway1 ⚠UnsynchronizedOr"}:::gw
    S410{"Skip CIM? ⚠UnsynchronizedOr"}:::gw
    S414{"Skip CIM join ⚠UnsynchronizedOr"}:::gw
    S424{"Everything complete ⚠And"}:::gw
    S428{"Transactions and Products"}:::gw
    S466{"KYC Approval Required?"}:::gw
    S469{"Approval declined?"}:::gw
    S483{"Call Credit"}:::gw
    S493{"BackToBanker ⚠UnsynchronizedOr"}:::gw
    S498{"Complete Process"}:::gw
    S503{"Pending Deals?"}:::gw
    S510{"«Frontline Banking Consultant» Bypass Bankerer"}:::gw
    S20(["End: Request Terminated"]):::endEv
    S15(["End: Request Completed"]):::endEv
    S55 --> S47
    S47 -->|"Request Terminated"| S301
    S10 -->|"Requests Terminated"| S301
    S301 --> S20
    S329 -->|"Fraud Trigger"| S333
    S333 --> S337
    S337 -->|"Request Terminated"| S301
    S375 --> S347
    S347 --> S380
    S329 -->|"Default…"| S396
    S337 -->|"Default…"| S396
    S405 -->|"Default…"| S396
    S396 -->|"Default…"| S408
    S408 --> S410
    S410 -->|"Default…"| S56
    S410 -->|"checkCimVerificationRequiredResponse/ski…"| S414
    S428 --> S375
    S428 --> S432
    S432 --> S419
    S10 -->|"Rejected"| S55
    S351 -->|"Products Not Enabled"| S405
    S10 -->|"Completed"| S428
    S380 -->|"Default…"| S424
    S424 --> S351
    S414 --> S10
    S419 --> S461
    S461 --> S424
    S56 -->|"Default…"| S466
    S466 -->|"initiateCAPAProcess/commonProcessData/co…"| S76
    S76 --> S469
    S469 -->|"initiateCAPAProcess/commonProcessData/co…"| S410
    S469 -->|"Default…"| S414
    S466 -->|"Default…"| S414
    S47 -->|"Default…"| S482
    S482 --> S483
    S483 -->|"send to credit"| S477
    S477 -->|"Default…"| S487
    S487 -->|"Default…"| S479
    S483 -->|"Do not call Credit"| S329
    S479 -->|"Default…"| S493
    S493 -->|"Default…"| S55
    S501 --> S503
    S503 -->|"Default…"| S498
    S503 -->|"checkForPendingDealsResponse/dealsPendin…"| S493
    S7 --> S507
    S507 --> S510
    S510 -->|"checkBankerValidationRequiredResponse/sk…"| S47
    S510 -->|"Default…"| S55
    S351 --> S501
    S498 -->|"Default…"| S296
    S296 --> S544
    S544 -->|"Default…"| S15
    classDef startEv fill:#d4edda,stroke:#28a745,stroke-width:2px
    classDef endEv fill:#f8d7da,stroke:#dc3545,stroke-width:2px
    classDef gw fill:#fff3cd,stroke:#b8860b
    classDef task fill:#cce5ff,stroke:#004085
    classDef proc fill:#e2d9f3,stroke:#4b0082,stroke-width:2px
    classDef svc fill:#eeeeee,stroke:#666
    classDef errEv fill:#f8d7da,stroke:#dc3545,stroke-dasharray: 4 3
    classDef catch fill:#d1ecf1,stroke:#0c5460
```

**Legend:** rounded = events (⚡ dashed red = error/boundary, ✉ = message catch) · diamond = gateway · 🧑‍💼 double-border = human task (MWS) · ⛓ purple = subprocess/model call · grey = service step · ⚠ = join that does not synchronise its inbound branches (see `3-design-review/parallel-gateway-defects.md`).

**Swimlane note:** nodes tagged «lane» sit outside the dominant lane (untagged = KYC Consultant); membership is derived from x-band containment only — lanes are not drawn, layout remains mermaid-computed. **Non-synchronising joins:** `«Frontline Banking Consultant» Capture and Validate Application` (UnsynchronizedOr); `Update KPI for Terminated` (UnsynchronizedOr); `Capture and Validate Complete?` (UnsynchronizedOr); `«Fraud Investigator» Trigger Fraud?` (UnsynchronizedOr); `«Fraud Investigator» Gateway1` (UnsynchronizedOr); `Skip CIM?` (UnsynchronizedOr); `Skip CIM join` (UnsynchronizedOr); `Everything complete` (And); `BackToBanker` (UnsynchronizedOr).

**Task/subprocess containers invoked:** `InvZaSbTpCAPACaptureValidateApplication`, `InvZaSbTpCAPAKYCStatusOverride`, `InvZaSbTpCAPAVerification`, `InvZaSbTpReferToFraud`
