# InvZaSbBpCaPAModel / EnableProduct — process flow (mermaid)

> Generated 2026-08-20 by `tools/mermaid_process.py` from
> `wm/ProcessModel/InvZaSbBpCaPAModel/EnableProduct.process` (baseline `8c87fe4a0`).
> Layout is mermaid-computed — Designer coordinates are not used.
> Internal — contains estate identifiers; do not distribute unsanitised.

| | |
|---|---|
| Steps | 18 (invokes 8, gateways 8) |
| Transitions | 21 |
| Swimlanes (not drawn — see note) | System |
| Non-synchronising joins ⚠ | 4 |
| Invoked task/subprocess packages | 0 |

```mermaid
flowchart TD
    S229(["Start InitiateEnableProductProcess"]):::startEv
    S293["createCiProductStructure"]:::svc
    S418["createNextCiProductStructure"]:::svc
    S431["Send Response"]:::svc
    S459["Prepare No CI Send Response"]:::svc
    S469["Prepare No PBA Send Response"]:::svc
    S480["Consolidate Enablement Product"]:::svc
    S483[["⛓ CreatePrivateBankAccountProduct"]]:::proc
    S486[["⛓ CreateCashInvestementsProduct"]]:::proc
    S191{"Can Proceed with CI"}:::gw
    S195{"SIN Empty?"}:::gw
    S213{"Send Response Gateway ⚠UnsynchronizedOr"}:::gw
    S353{"Create Product Gateway ⚠UnsynchronizedOr"}:::gw
    S462{"Initiate CI and/or PBA product"}:::gw
    S465{"Check if Applicant Details are populated for PBA"}:::gw
    S471{"Send PBA Product or Response ⚠UnsynchronizedOr"}:::gw
    S474{"PBA Product or Response ⚠And"}:::gw
    S435(["End: Completed"]):::endEv
    S191 -->|"Default…"| S213
    S195 -->|"SIN not empty"| S293
    S293 -->|"Default…"| S353
    S191 -->|"ciLoopComplete = false…"| S353
    S418 -->|"Default…"| S191
    S431 -->|"Default…"| S435
    S195 -->|"SIN is empty"| S459
    S459 --> S213
    S229 --> S462
    S462 --> S195
    S462 --> S465
    S465 -->|"Default…"| S469
    S469 -->|"Default…"| S471
    S471 --> S474
    S213 --> S474
    S474 --> S480
    S480 --> S431
    S465 -->|"InitiateEnableProductProcess/pbaProductD…"| S483
    S483 -->|"Default…"| S471
    S353 --> S486
    S486 --> S418
    classDef startEv fill:#d4edda,stroke:#28a745,stroke-width:2px
    classDef endEv fill:#f8d7da,stroke:#dc3545,stroke-width:2px
    classDef gw fill:#fff3cd,stroke:#b8860b
    classDef task fill:#cce5ff,stroke:#004085
    classDef proc fill:#e2d9f3,stroke:#4b0082,stroke-width:2px
    classDef svc fill:#eeeeee,stroke:#666
    classDef errEv fill:#f8d7da,stroke:#dc3545,stroke-dasharray: 4 3
    classDef catch fill:#d1ecf1,stroke:#0c5460
```

**Legend:** rounded = events (⚡ dashed red = error/boundary, ✉ = message catch) · diamond = gateway · 🧑‍💼 double-border = human task (MWS) · ⛓ purple = subprocess/model call · grey = service step · ⚠ = join that does not synchronise its inbound branches (see `3-design-review/parallel-gateway-defects.md`).

**Swimlane note:** summary view: service steps and gateways are contracted into edges; edge labels carry the non-default conditions and elided step counts. **Non-synchronising joins:** `Send Response Gateway` (UnsynchronizedOr); `Create Product Gateway` (UnsynchronizedOr); `Send PBA Product or Response` (UnsynchronizedOr); `PBA Product or Response` (And).

**Task/subprocess containers invoked:** none
