# InvZaSbBpCaPAModel / UploadDocumentProcess — process flow (mermaid)

> Generated 2026-08-20 by `tools/mermaid_process.py` from
> `wm/ProcessModel/InvZaSbBpCaPAModel/UploadDocumentProcess.process` (baseline `8c87fe4a0`).
> Layout is mermaid-computed — Designer coordinates are not used.
> Internal — contains estate identifiers; do not distribute unsanitised.

| | |
|---|---|
| Steps | 5 (invokes 1, gateways 0) |
| Transitions | 3 + 1 boundary attachment(s) |
| Swimlanes (not drawn — see note) | System |
| Non-synchronising joins ⚠ | 0 |
| Invoked task/subprocess packages | 0 |

```mermaid
flowchart TD
    S7(["Start addContentBpRequest1"]):::startEv
    S11["Upload Documents to Documentum"]:::svc
    S8(["End: Complete"]):::endEv
    S10(["End: Upload failed"]):::endEv
    S14(["⚡boundary: Error1"]):::errEv
    S7 --> S11
    S11 --> S8
    S14 --> S10
    S11 -.->|"on error"| S14
    classDef startEv fill:#d4edda,stroke:#28a745,stroke-width:2px
    classDef endEv fill:#f8d7da,stroke:#dc3545,stroke-width:2px
    classDef gw fill:#fff3cd,stroke:#b8860b
    classDef task fill:#cce5ff,stroke:#004085
    classDef proc fill:#e2d9f3,stroke:#4b0082,stroke-width:2px
    classDef svc fill:#eeeeee,stroke:#666
    classDef errEv fill:#f8d7da,stroke:#dc3545,stroke-dasharray: 4 3
    classDef catch fill:#d1ecf1,stroke:#0c5460
```

**Legend:** rounded = events (⚡ dashed red = error/boundary, ✉ = message catch) · diamond = gateway · 🧑‍💼 double-border = human task (MWS) · ⛓ purple = subprocess/model call · grey = service step · ⚠ = join that does not synchronise its inbound branches (see `3-design-review/parallel-gateway-defects.md`).

**Swimlane note:** summary view: service steps and gateways are contracted into edges; edge labels carry the non-default conditions and elided step counts. **Non-synchronising joins:** none.

**Task/subprocess containers invoked:** none
