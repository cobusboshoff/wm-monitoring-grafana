package PoRequestFrontEnd;

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import org.apache.skywalking.apm.agent.core.context.ContextManager;
import org.apache.skywalking.apm.agent.core.context.trace.AbstractSpan;
import org.apache.skywalking.apm.agent.core.context.ContextCarrier;
import org.apache.skywalking.apm.agent.core.context.CarrierItem;
import org.apache.skywalking.apm.agent.core.base64.Base64;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
// --- <<IS-END-IMPORTS>> ---

public final class trace
{
    public static final void stampContextId (IData pipeline) throws ServiceException
    {
        // --- <<IS-START(stampContextId)>> ---
        // Entry-point tracing hook. Call as the FIRST step of the top-level
        // HTTP-invoked service so it acts on the root span.
        //
        // If this transaction arrived over HTTP with a W3C `traceparent` header
        // (e.g. a Dynatrace-instrumented external caller), it:
        //   1) extracts the 128-bit trace-id and registers it as the IS custom
        //      context id (pub.flow:setCustomContextID). The webMethods E2E agent
        //      stamps that value as the span `custom_tnx_id` -- session-wide, so
        //      it rides to every service incl. E2E-linked async/publish downstream.
        //   2) sets explicit external.* span TAGS on the active span via the
        //      SkyWalking core API, so the external trace-id is also directly
        //      searchable per-span.
        //   3) (SPIKE, behind WMOBS_TRACE_MERGE) optionally RE-KEYS the live IS
        //      trace segment to the client's W3C trace-id, so the IS spans render
        //      in the SAME Tempo trace as the external client -- one merged
        //      waterfall instead of two attribute-linked traces. Default OFF.
        //
        // All of it is best-effort: a tracing concern must NEVER break the flow.
        try {
            IData ti = Service.doInvoke("pub.flow", "getTransportInfo", IDataFactory.create());
            String traceparent = header(ti, "traceparent");
            String tracestate  = header(ti, "tracestate");
            String xdynatrace  = header(ti, "x-dynatrace");

            String traceId = null;
            String spanId  = null;
            if (traceparent != null) {
                // W3C traceparent = version(2) "-" traceid(32) "-" spanid(16) "-" flags(2)
                String[] p = traceparent.trim().split("-");
                if (p.length >= 2 && p[1].length() == 32) {
                    traceId = p[1];
                }
                if (p.length >= 3 && p[2].length() == 16) {
                    spanId = p[2];
                }
            }

            if (traceId != null) {
                // (1) correlation id -> E2E custom_tnx_id (session scoped)
                IData in = IDataFactory.create();
                IDataCursor ic = in.getCursor();
                IDataUtil.put(ic, "id", traceId);
                ic.destroy();
                Service.doInvoke("pub.flow", "setCustomContextID", in);

                // (2) explicit span tags on the active (root) span
                tag("external.trace_id", traceId);
                tag("external.traceparent", traceparent);
                tag("external.tracestate", tracestate);
                tag("external.caller", "w3c-tracecontext");

                // (3) SPIKE: single-trace merge (re-key the IS segment). OFF by default.
                String mode = mergeMode();
                String mergeResult = "off";
                if ("carrier".equals(mode)) {
                    mergeResult = mergeViaCarrier(traceId, spanId);
                } else if ("reflect".equals(mode)) {
                    mergeResult = mergeViaReflection(traceId);
                }
                IDataCursor mc = pipeline.getCursor();
                IDataUtil.put(mc, "dtMergeMode", mode);
                IDataUtil.put(mc, "dtMergeResult", mergeResult);
                mc.destroy();
            }

            // Surface what we found on the pipeline (visibility / debug).
            IDataCursor pc = pipeline.getCursor();
            if (traceId != null)     IDataUtil.put(pc, "dtTraceId", traceId);
            if (traceparent != null) IDataUtil.put(pc, "dtTraceparent", traceparent);
            if (tracestate != null)  IDataUtil.put(pc, "dtTracestate", tracestate);
            if (xdynatrace != null)  IDataUtil.put(pc, "dtXDynatrace", xdynatrace);
            pc.destroy();
        } catch (Exception e) {
            IDataCursor pc = pipeline.getCursor();
            IDataUtil.put(pc, "dtTraceError", String.valueOf(e.getMessage()));
            pc.destroy();
        }
        // --- <<IS-END>> ---
    }

    // --- <<IS-START-SHARED>> ---
    // Best-effort span tag via the SkyWalking core API. The E2E agent loads
    // SkyWalking on the JVM bootclasspath (javaagent), so these calls resolve at
    // runtime; the source is compiled against uha-apm-agent.jar. Never throws.
    static void tag(String key, String value)
    {
        if (value == null) return;
        try {
            if (ContextManager.isActiveSpanValid()) {
                AbstractSpan span = ContextManager.activeSpan();
                if (span != null) span.tag(key, value);
            }
        } catch (Throwable ignore) {}
    }

    // ------------------------------------------------------------------
    // SPIKE: single-trace merge helpers (behind WMOBS_TRACE_MERGE)
    // ------------------------------------------------------------------
    // The webMethods E2E agent (SkyWalking-v6 derivative, uha-apm-agent) mints
    // its own trace-id for the IS segment, so an inbound W3C client trace and the
    // IS trace are two disjoint Tempo traces. But the OTLP trace-id is read at
    // SEGMENT FINISH from TraceSegment.relatedGlobalTraces.get(0), and
    // DistributedTraceIds.append() REPLACES the head auto-generated
    // NewDistributedTraceId with the first propagated id. So handing the agent a
    // ContextCarrier (or a PropagatedTraceId) carrying the client's 32-hex id from
    // this first flow step re-keys the live segment -> the IS spans export under
    // the client's trace-id -> one merged waterfall.
    //
    // In mcsp mode the agent stores ids as raw hex (ID.otlpId), so
    // PropagatedTraceId(clientHex).toUniqueOtlpId() == clientHex and OtlpTransform
    // takes the ByteString.fromHex() branch -- pass-through, no reformatting.
    //
    // Both variants fail CLOSED: any problem leaves today's two-trace behaviour.

    // Resolve the toggle. Values: "carrier" | "reflect" | anything else = off.
    // Read a runtime flag FILE first (so the mode can be flipped live via
    // `docker exec ... > wmobs-trace-merge` with no container restart -- it is
    // re-read every invocation), then fall back to the WMOBS_TRACE_MERGE env var.
    static final String MERGE_FLAG_FILE =
        "/opt/softwareag/IntegrationServer/instances/default/config/wmobs-trace-merge";

    static String mergeMode()
    {
        // 1) runtime flag file (live-flippable)
        try {
            java.io.File f = new java.io.File(MERGE_FLAG_FILE);
            if (f.isFile()) {
                byte[] b = java.nio.file.Files.readAllBytes(f.toPath());
                String v = new String(b, "UTF-8").trim().toLowerCase();
                if ("carrier".equals(v) || "reflect".equals(v)) return v;
                if ("off".equals(v) || v.isEmpty()) return "off";
            }
        } catch (Throwable ignore) {}
        // 2) environment variable (compose-level default)
        try {
            String v = System.getenv("WMOBS_TRACE_MERGE");
            if (v != null) {
                v = v.trim().toLowerCase();
                if ("carrier".equals(v) || "reflect".equals(v)) return v;
            }
        } catch (Throwable ignore) {}
        return "off";
    }

    // Variant A -- PUBLIC API only. Build a valid sw6-v2 ContextCarrier carrying
    // the client trace-id and call ContextManager.extract(). extract() appends the
    // carrier's distributed trace-id to the segment (re-keying it) AND attaches a
    // cross-process ref -> an OTLP span link back to the client.
    // sw6-v2 wire format (verified against ContextCarrier.serialize/deserialize):
    //   1 - b64(traceId) - b64(segmentId) - spanId - parentSvcInstId - entrySvcInstId
    //     - b64(peerHost) - b64(entryEndpoint) - b64(parentEndpoint)
    //     - b64(parentLandscape) - b64(parentComponent)
    static final String PTID_CLASS =
        "org.apache.skywalking.apm.agent.core.context.ids.PropagatedTraceId";
    static final String ID_CLASS =
        "org.apache.skywalking.apm.agent.core.context.ids.ID";

    static String mergeViaCarrier(String traceHex, String clientSpanHex)
    {
        try {
            if (!ContextManager.isActiveSpanValid()) return "no-active-span";
            // fabricate a valid 32-hex segment id; anchor it to the client span id
            // when present (purely cosmetic -- the ref becomes an OTLP link).
            String seg = (clientSpanHex != null ? clientSpanHex : "0000000000000000")
                         + "0000000000000000";

            // Attempt 1 -- PUBLIC API: hand-build the sw6-v2 wire string and feed
            // it through CarrierItem.setHeadValue(). NOTE: this parses cleanly in a
            // standalone JVM but mis-parses inside the fully-bootstrapped agent
            // (observed: NumberFormatException on the peerHost field). Kept as the
            // "pure public API" path for environments where it holds; the status
            // records the failure and we fall through to Attempt 2.
            String sw6note = "sw6:not-tried";
            try {
                // peerHost / entry+parent endpoint MUST be '#'-prefixed: the
                // TraceSegmentRef ctor treats a non-'#' value as a numeric
                // registered id and Integer.parseInt()s it (NumberFormatException
                // otherwise). '#' marks a literal (unregistered) address/endpoint.
                String sw6 = String.join("-",
                    "1",
                    Base64.encode(traceHex),
                    Base64.encode(seg),
                    "1", "1", "1",
                    Base64.encode("#external-w3c-client"),
                    Base64.encode("#/client-http-call"),
                    Base64.encode("#/client-http-call"),
                    Base64.encode("external"),
                    Base64.encode("http"));
                ContextCarrier carrier = new ContextCarrier();
                CarrierItem item = carrier.items();
                while (item.hasNext()) {
                    item = item.next();
                    if ("sw6".equals(item.getHeadKey())) item.setHeadValue(sw6);
                }
                if (carrier.isValid()) {
                    ContextManager.extract(carrier);
                    return "applied:carrier-sw6:" + ContextManager.getGlobalTraceId();
                }
                sw6note = "sw6:invalid";
            } catch (Throwable t1) {
                StackTraceElement[] st = t1.getStackTrace();
                sw6note = "sw6:" + t1.getClass().getSimpleName()
                        + (st.length > 0 ? "@" + st[0].getMethodName() + ":" + st[0].getLineNumber() : "");
            }

            // Attempt 2 -- reflection-populate the carrier (robust), then extract().
            ContextCarrier carrier = new ContextCarrier();
            Object ptid = Class.forName(PTID_CLASS)
                .getConstructor(String.class).newInstance(traceHex);
            Object segId = Class.forName(ID_CLASS)
                .getConstructor(String.class, boolean.class).newInstance(seg, true);
            setCarrierField(carrier, "primaryDistributedTraceId", ptid);
            setCarrierField(carrier, "traceSegmentId", segId);
            setCarrierField(carrier, "spanId", Integer.valueOf(1));
            setCarrierField(carrier, "parentServiceInstanceId", Integer.valueOf(1));
            setCarrierField(carrier, "entryServiceInstanceId", Integer.valueOf(1));
            setCarrierField(carrier, "peerHost", "#external-w3c-client");
            setCarrierField(carrier, "entryEndpointName", "#/client-http-call");
            setCarrierField(carrier, "parentEndpointName", "#/client-http-call");
            setCarrierField(carrier, "parentLandscape", "external");
            setCarrierField(carrier, "parentComponent", "http");
            if (!carrier.isValid()) return "invalid-carrier(" + sw6note + ")";
            ContextManager.extract(carrier);
            return "applied:carrier-reflect(" + sw6note + "):" + ContextManager.getGlobalTraceId();
        } catch (Throwable t) {
            return "error:" + t.getClass().getSimpleName() + ":" + t.getMessage();
        }
    }

    static void setCarrierField(ContextCarrier c, String name, Object val) throws Exception
    {
        Field f = ContextCarrier.class.getDeclaredField(name);
        f.setAccessible(true);
        if (val instanceof Integer) f.setInt(c, ((Integer) val).intValue());
        else f.set(c, val);
    }

    // Variant B -- REFLECTION. Reach the active TracingContext.segment and call
    // its public relatedGlobalTraces(new PropagatedTraceId(hex)) directly. Pure
    // trace-id swap: no cross-process ref, no OTLP link, cleanest topology. Uses
    // only the agent classes already on the bootclasspath.
    static String mergeViaReflection(String traceHex)
    {
        try {
            if (!ContextManager.isActiveSpanValid()) return "no-active-span";

            Class<?> cmClass = Class.forName(
                "org.apache.skywalking.apm.agent.core.context.ContextManager");
            Field ctxField = cmClass.getDeclaredField("CONTEXT");
            ctxField.setAccessible(true);
            ThreadLocal<?> tl = (ThreadLocal<?>) ctxField.get(null);
            Object ctx = (tl == null) ? null : tl.get();
            if (ctx == null) return "no-context";

            Field segField;
            try {
                segField = ctx.getClass().getDeclaredField("segment");
            } catch (NoSuchFieldException nsf) {
                return "no-segment(" + ctx.getClass().getSimpleName() + ")";
            }
            segField.setAccessible(true);
            Object segment = segField.get(ctx);
            if (segment == null) return "null-segment";

            Object ptid = Class.forName(
                "org.apache.skywalking.apm.agent.core.context.ids.PropagatedTraceId")
                .getConstructor(String.class).newInstance(traceHex);
            Class<?> dtidClass = Class.forName(
                "org.apache.skywalking.apm.agent.core.context.ids.DistributedTraceId");
            Method m = segment.getClass().getMethod("relatedGlobalTraces", dtidClass);
            m.invoke(segment, ptid);
            return "applied:reflect:" + ContextManager.getGlobalTraceId();
        } catch (Throwable t) {
            return "error:" + t.getClass().getSimpleName() + ":" + t.getMessage();
        }
    }

    // Case-insensitive lookup of an HTTP header in pub.flow:getTransportInfo
    // output (transport/http/requestHdrs). Returns null if not HTTP-invoked or
    // the header is absent.
    static String header(IData transportInfo, String name)
    {
        if (transportInfo == null) return null;
        IDataCursor tc = transportInfo.getCursor();
        IData transport = IDataUtil.getIData(tc, "transport");
        tc.destroy();
        if (transport == null) return null;

        IDataCursor sc = transport.getCursor();
        IData http = IDataUtil.getIData(sc, "http");
        sc.destroy();
        if (http == null) return null;

        IDataCursor hc = http.getCursor();
        IData hdrs = IDataUtil.getIData(hc, "requestHdrs");
        hc.destroy();
        if (hdrs == null) return null;

        IDataCursor rc = hdrs.getCursor();
        String found = null;
        while (rc.next()) {
            String k = rc.getKey();
            if (k != null && k.equalsIgnoreCase(name)) {
                Object v = rc.getValue();
                if (v instanceof String[]) {
                    String[] arr = (String[]) v;
                    found = (arr.length > 0) ? arr[0] : null;
                } else {
                    found = (v != null) ? v.toString() : null;
                }
                break;
            }
        }
        rc.destroy();
        return found;
    }
    // --- <<IS-END-SHARED>> ---
}
