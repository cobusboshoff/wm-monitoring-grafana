package inv.platform;

// -----( IS Java Code Template v1.2
//
// InvCommonPlatformMetrics — in-process, license-free sag_is_* exporter.
// render:        builds Prometheus exposition text and returns it as the HTTP response.
// registerAlias: startup service; maps /platform/metrics -> invoke/inv.platform.metrics:render (no license check).
//
// Metric sources (all license-free, confirmed under PIESS / Microservices=no):
//   Task 1 (this file): JVM/OS families via java.lang.management + com.sun.management MXBeans.
//   Task 2 (todo):      per-service families via wm.server.query:getServiceStats.
//   Task 3 (todo):      server-aggregate families via wm.server.query:getStats.
// Names/HELP/TYPE mirror the MSR native endpoint (frozen golden capture) so dashboards are source-agnostic.
// No per-line timestamp — Prometheus stamps at scrape (avoids VM-clock-jump TSDB poisoning).

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryUsage;
import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ThreadMXBean;
import java.lang.management.ThreadInfo;
import java.lang.management.ClassLoadingMXBean;
import java.lang.management.BufferPoolMXBean;
import java.net.InetAddress;
import java.io.File;
import java.util.List;
// --- <<IS-END-IMPORTS>> ---

public final class metrics
{
	// ---( internal utility methods )---

	final static metrics _instance = new metrics();

	static metrics _newInstance() { return new metrics(); }

	static metrics _cast(Object o) { return (metrics)o; }

	// ---( server methods )---

	public static final void render (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(render)>> ---
		// @sigtype java 3.5
		// Config-driven engine: emit each family whose category is ON and enabled=true.
		//  - getStats families -> data-driven from the config rows (name/help/type/key)
		//  - computed families (jvm/os/uptime) -> gated Java collectors (collectComputed)
		//  - serviceStats families -> gated per-service (collectServiceStats)
		StringBuilder sb = new StringBuilder(16384);
		String host = hostname();
		String hostLbl = "host=\"" + host + "\"";
		try {
			IData cfg = loadConfig();
			IDataCursor cc = cfg.getCursor();
			IData cats = IDataUtil.getIData(cc, "categories");
			IData[] fams = IDataUtil.getIDataArray(cc, "families");
			cc.destroy();
			java.util.Set<String> en = new java.util.HashSet<String>();
			java.util.List<IData> statsRows = new java.util.ArrayList<IData>();
			boolean anyComputed = false, anyService = false;
			if (fams != null) for (IData f : fams) {
				IDataCursor fc = f.getCursor();
				String name = IDataUtil.getString(fc, "name");
				String cat  = IDataUtil.getString(fc, "category");
				String src  = IDataUtil.getString(fc, "source");
				boolean on = "true".equalsIgnoreCase(String.valueOf(IDataUtil.get(fc, "enabled"))) && catOn(cats, cat);
				fc.destroy();
				if (!on) continue;
				en.add(name);
				if ("getStats".equals(src)) statsRows.add(f);
				else if ("serviceStats".equals(src)) anyService = true;
				else anyComputed = true;
			}
			if (!statsRows.isEmpty()) {
				java.util.Map<String,String> stats = statsMap();
				for (IData f : statsRows) {
					IDataCursor fc = f.getCursor();
					String name = IDataUtil.getString(fc, "name"), help = IDataUtil.getString(fc, "help"),
					       type = IDataUtil.getString(fc, "type"), key = IDataUtil.getString(fc, "key");
					fc.destroy();
					String v = stats.get(key);
					if (v != null) { header(sb, name, help, type); line(sb, name, hostLbl, v); }
				}
			}
			if (anyComputed) collectComputed(sb, host, hostLbl, en);
			if (anyService)  collectServiceStats(sb, hostLbl, en);
		} catch (Throwable t) { /* never blank the endpoint */ }
		writeResponse(sb.toString());
		// --- <<IS-END>> ---
	}

	public static final void registerAlias (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(registerAlias)>> ---
		// @sigtype java 3.5
		// Manual, idempotent alias (re)register helper — NOT a startup service. The alias is
		// registered automatically by IS from the package's config/urlalias.cnf at load; making
		// this a startup service too caused both to register and logged an "Already registered by
		// package" warning. Kept as a hand-invokable repair (recreate the alias if it's deleted);
		// the aliasExists() guard makes it a no-op when already present.
		try {
			String alias = cfgAlias(loadConfig());
			if (aliasExists(alias)) return;
			addAlias(alias);
		} catch (Exception e) { throw new ServiceException(e); }
		// --- <<IS-END>> ---
	}

	public static final void unregisterAlias (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(unregisterAlias)>> ---
		// @sigtype java 3.5
		// Teardown counterpart to registerAlias: remove the /platform/metrics alias (idempotent —
		// no-op if already absent). Hand-invokable via GET or POST. deleteAlias also removes the
		// entry from config/urlalias.cnf, so the alias stays gone across reloads AND restarts
		// (permanent removal, not a runtime toggle); invoke registerAlias to restore it.
		try {
			String alias = cfgAlias(loadConfig());
			if (!aliasExists(alias)) return;
			delAlias(alias);
		} catch (Exception e) { throw new ServiceException(e); }
		// --- <<IS-END>> ---
	}

	public static final void getConfig (IData pipeline) throws ServiceException {
		// --- <<IS-START(getConfig)>> ---
		// @sigtype java 3.5
		// Return the live config.json (seeded from the shipped default on first use).
		try {
			IData cfg = loadConfig();
			java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
			new com.wm.util.coder.IDataJSONCoder().encode(b, cfg);
			IData in = IDataFactory.create();
			IDataCursor c = in.getCursor();
			IDataUtil.put(c, "string", b.toString("UTF-8"));
			IDataUtil.put(c, "contentType", "application/json; charset=utf-8");
			c.destroy();
			Service.doInvoke("pub.flow", "setResponse", in);
		} catch (Exception e) { throw new ServiceException(e); }
		// --- <<IS-END>> ---
	}

	public static final void saveConfig (IData pipeline) throws ServiceException {
		// --- <<IS-START(saveConfig)>> ---
		// @sigtype java 3.5
		// POST body = {"config": <full config doc>} — IS's JSON content handler parses it into
		// the pipeline, so "config" arrives as an IData. Validate, stamp, persist, invalidate cache.
		// Administrator-gated (see pub/.access + this service's ACL).
		try {
			IDataCursor c = pipeline.getCursor();
			IData doc = IDataUtil.getIData(c, "config");
			c.destroy();
			if (doc == null) throw new ServiceException("missing 'config'");
			IDataCursor dc = doc.getCursor();
			IData[] fams = IDataUtil.getIDataArray(dc, "families");
			if (fams == null) { dc.destroy(); throw new ServiceException("invalid config: families[] required"); }
			IDataUtil.put(dc, "lastUpdated",
				new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date()));
			dc.destroy();
			// capture the currently-registered alias BEFORE overwriting, so an alias change in the
			// Settings UI can be applied: drop the old alias, register the new one (both persist to
			// config/urlalias.cnf). A no-op when the alias is unchanged.
			String oldAlias = cfgAlias(loadConfig());
			writeJson(pkgFile("config/config.json"), doc);
			invalidateConfig();
			String newAlias = cfgAlias(doc);
			if (!newAlias.equals(oldAlias)) {
				try { if (aliasExists(oldAlias)) delAlias(oldAlias); } catch (Exception ignore) {}
				try { if (!aliasExists(newAlias)) addAlias(newAlias); } catch (Exception ignore) {}
			}
			IData in = IDataFactory.create(); IDataCursor ic = in.getCursor();
			IDataUtil.put(ic, "string", "{\"status\":\"ok\"}");
			IDataUtil.put(ic, "contentType", "application/json");
			ic.destroy();
			Service.doInvoke("pub.flow", "setResponse", in);
		} catch (ServiceException se) { throw se; }
		  catch (Exception e) { throw new ServiceException(e); }
		// --- <<IS-END>> ---
	}

	public static final void snapshot (IData pipeline) throws ServiceException {
		// --- <<IS-START(snapshot)>> ---
		// @sigtype java 3.5
		// Curated live health snapshot as JSON for the Home-tab widget.
		try {
			java.util.Map<String,String> st = statsMap();
			MemoryMXBean mem = ManagementFactory.getMemoryMXBean();
			long heapUsed = mem.getHeapMemoryUsage().getUsed() / MB;
			long heapMax  = mem.getHeapMemoryUsage().getMax() / MB;
			long uptime   = ManagementFactory.getRuntimeMXBean().getUptime() / 1000L;
			int  threads  = ManagementFactory.getThreadMXBean().getThreadCount();
			int emitted = 0, total = 0;
			IData cfg = loadConfig(); IDataCursor cc = cfg.getCursor();
			IData cats = IDataUtil.getIData(cc, "categories");
			IData[] fams = IDataUtil.getIDataArray(cc, "families");
			cc.destroy();
			if (fams != null) for (IData f : fams) {
				IDataCursor fc = f.getCursor();
				boolean caton = catOn(cats, IDataUtil.getString(fc, "category"));
				boolean en = "true".equalsIgnoreCase(String.valueOf(IDataUtil.get(fc, "enabled")));
				fc.destroy();
				if (caton) { total++; if (en) emitted++; }
			}
			IData snap = IDataFactory.create(); IDataCursor s = snap.getCursor();
			IDataUtil.put(s, "endpointUp", Boolean.valueOf(aliasExists(cfgAlias(cfg))));
			IDataUtil.put(s, "familiesEmitted", Integer.valueOf(emitted));
			IDataUtil.put(s, "familiesTotal", Integer.valueOf(total));
			IDataUtil.put(s, "uptimeSec", Long.valueOf(uptime));
			IDataUtil.put(s, "heapUsedMb", Long.valueOf(heapUsed));
			IDataUtil.put(s, "heapMaxMb", Long.valueOf(heapMax));
			IDataUtil.put(s, "threads", Integer.valueOf(threads));
			IDataUtil.put(s, "errorsPerMin", st.get("errSvcPM"));
			IDataUtil.put(s, "reqPerMin", st.get("endReqPM"));
			String rawE = rawEnv(cfg);
			IDataUtil.put(s, "environment", envTier(rawE));                       // css tier: dev|qa|uat|prod|unknown
			IDataUtil.put(s, "environmentLabel", rawE.isEmpty() ? "UNKNOWN" : rawE.toUpperCase());
			s.destroy();
			java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
			new com.wm.util.coder.IDataJSONCoder().encode(b, snap);
			IData in = IDataFactory.create(); IDataCursor ic = in.getCursor();
			IDataUtil.put(ic, "string", b.toString("UTF-8"));
			IDataUtil.put(ic, "contentType", "application/json; charset=utf-8");
			ic.destroy();
			Service.doInvoke("pub.flow", "setResponse", in);
		} catch (Exception e) { throw new ServiceException(e); }
		// --- <<IS-END>> ---
	}

	// --- <<IS-START-SHARED>> ---

	private static final long MB = 1024L * 1024L;

	// ===== Config loader (A1): live config/config.json, seeded from resources default =====
	// user.dir is the IS instance dir at runtime (verified 2026-07-24: .../instances/default). If that
	// ever changes, mirror ngProtonAdmin DashboardHelper.resolveInstanceFile's search strategy here.
	static java.io.File pkgFile(String rel) {
		return new java.io.File(new java.io.File(System.getProperty("user.dir")),
			"packages/InvCommonPlatformMetrics/" + rel);
	}
	static IData readJson(java.io.File f) throws Exception {
		try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
			return new com.wm.util.coder.IDataJSONCoder().decode(in);
		}
	}
	static void writeJson(java.io.File f, IData doc) throws Exception {
		if (f.getParentFile() != null) f.getParentFile().mkdirs();
		try (java.io.FileOutputStream out = new java.io.FileOutputStream(f)) {
			new com.wm.util.coder.IDataJSONCoder().encode(out, doc);
		}
	}
	private static IData CFG; private static long CFG_AT;
	// live config, seeding config/config.json from the shipped default on first use;
	// 2s cache so rapid scrapes don't re-read the file each time
	static synchronized IData loadConfig() throws Exception {
		long now = System.nanoTime();
		if (CFG != null && (now - CFG_AT) < 2_000_000_000L) return CFG;
		java.io.File live = pkgFile("config/config.json");
		if (!live.exists()) writeJson(live, readJson(pkgFile("resources/config-default.json")));
		CFG = readJson(live); CFG_AT = now; return CFG;
	}
	static void invalidateConfig() { CFG = null; }

	// configured alias (endpoint.alias in the config), defaulting to platform/metrics when unset.
	// The render service itself is alias-agnostic — whatever alias points at invoke/inv.platform.metrics:render
	// serves the metrics — but registerAlias/unregisterAlias/snapshot and the saveConfig re-register path
	// all need the SAME name, so we source it from one place.
	static String cfgAlias(IData cfg) {
		if (cfg == null) return "platform/metrics";
		IDataCursor c = cfg.getCursor();
		IData ep = IDataUtil.getIData(c, "endpoint");
		c.destroy();
		if (ep == null) return "platform/metrics";
		IDataCursor e = ep.getCursor();
		String a = IDataUtil.getString(e, "alias");
		e.destroy();
		return (a == null || a.trim().isEmpty()) ? "platform/metrics" : a.trim();
	}
	// addAlias needs package= to persist (writes config/urlalias.cnf) and association="1" so a
	// multi-segment alias resolves; isDefaultPath="true" silently yields an alias with no usable urlPath.
	static void addAlias(String alias) throws Exception {
		IData in = IDataFactory.create(); IDataCursor c = in.getCursor();
		IDataUtil.put(c, "alias", alias);
		IDataUtil.put(c, "urlPath", "invoke/inv.platform.metrics:render");
		IDataUtil.put(c, "association", "1");
		IDataUtil.put(c, "package", "InvCommonPlatformMetrics");
		c.destroy();
		Service.doInvoke("wm.server.httpUrlAlias", "addAlias", in);
	}
	// deleteAlias also clears the urlalias.cnf entry (permanent removal, survives reload/restart).
	static void delAlias(String alias) throws Exception {
		IData in = IDataFactory.create(); IDataCursor c = in.getCursor();
		IDataUtil.put(c, "alias", alias);
		c.destroy();
		Service.doInvoke("wm.server.httpUrlAlias", "deleteAlias", in);
	}

	// ===== Environment indicator (console header colour by DEV/QA/UAT/PROD) =====
	// Resolves the deployment environment for the console header strip. Precedence:
	//   1. IS extended setting  watt.inv.platform.metrics.env  (set once per instance in Admin > Extended Settings;
	//      inherited by every package that reuses this console template — the cross-package single
	//      source of truth, so two packages on one box can never disagree about which env it is)
	//   2. the package config file's top-level "environment" field (standalone / dev-box fallback)
	//   3. neither set -> "" -> UNKNOWN (fails safe: never masquerades as DEV or PROD)
	// The environment is a property of the box, never a per-browser UI setting.
	static String rawEnv(IData cfg) {
		String v = wattProp("watt.inv.platform.metrics.env");
		if (v == null || v.trim().isEmpty()) {
			if (cfg != null) {
				IDataCursor c = cfg.getCursor();
				v = IDataUtil.getString(c, "environment");
				c.destroy();
			}
		}
		return (v == null) ? "" : v.trim();
	}
	// Read an IS extended setting (watt.*) straight from config/server.cnf — a flat java.util.Properties
	// file. NOTE: com.wm.util.Config.getProperty looked right but reads the client-tools config, not the
	// running server's watt store, so it returned empty for a live extended setting. server.cnf, located
	// via ServerAPI.getServerConfigDir(), is the authoritative source and is a plain key=value file.
	static String wattProp(String key) {
		try {
			java.io.File cnf = new java.io.File(
				com.wm.app.b2b.server.ServerAPI.getServerConfigDir(), "server.cnf");
			if (!cnf.exists()) return "";
			java.util.Properties p = new java.util.Properties();
			try (java.io.FileInputStream in = new java.io.FileInputStream(cnf)) { p.load(in); }
			String v = p.getProperty(key);
			return (v == null) ? "" : v.trim();
		} catch (Throwable t) { return ""; }
	}
	// Map a free-text env name onto one of four colour tiers (dev|qa|uat|prod) or "unknown".
	// NOTE: "preprod"/"pre-prod"/"staging" contain the substring "prod", so they MUST be tested
	// before the plain prod check — otherwise PREPROD would light up red instead of amber (uat slot).
	static String envTier(String raw) {
		String e = (raw == null ? "" : raw).toLowerCase();
		if (e.isEmpty())                                                  return "unknown";
		if (e.contains("preprod") || e.contains("pre-prod") || e.contains("stag")) return "uat";
		if (e.contains("prod"))                                          return "prod";
		if (e.contains("uat") || e.contains("accept"))                   return "uat";
		if (e.contains("qa") || e.contains("test") || e.contains("sit")) return "qa";
		if (e.contains("dev"))                                           return "dev";
		return "unknown";
	}

	// ===== Task 1: JVM + OS families (28) — all license-free MXBeans =====
	// ===== Computed families (jvm/os/uptime) — gated by the enabled-name set =====
	static void collectComputed(StringBuilder sb, String host, String hostLbl, java.util.Set<String> en)
	{
		if (en.contains("sag_is_uptime_seconds")) {
			header(sb, "sag_is_uptime_seconds", "Uptime for Server", "counter");
			line(sb, "sag_is_uptime_seconds", hostLbl, ManagementFactory.getRuntimeMXBean().getUptime() / 1000L);
		}
		MemoryMXBean mem = ManagementFactory.getMemoryMXBean();
		gG(en, sb, "sag_is_jvm_memory_heap_used_mbytes", "The total number of allocated megabytes from heap memory", hostLbl, mem.getHeapMemoryUsage().getUsed() / MB);
		gG(en, sb, "sag_is_jvm_memory_nonheap_used_mbytes", "The total number of allocated megabytes NOT from heap memory", hostLbl, mem.getNonHeapMemoryUsage().getUsed() / MB);
		gG(en, sb, "sag_is_jvm_objects_pending_finalizer_count", "The number of objects ready for GC", hostLbl, mem.getObjectPendingFinalizationCount());
		if (en.contains("sag_is_jvm_memory_pool_max_mbytes")) {
			header(sb, "sag_is_jvm_memory_pool_max_mbytes", "The total number of allocated megabytes in the named memory pool", "gauge");
			for (MemoryPoolMXBean p : ManagementFactory.getMemoryPoolMXBeans()) {
				MemoryUsage u = p.getUsage(); long mb = (u != null) ? u.getUsed() / MB : 0L;
				line(sb, "sag_is_jvm_memory_pool_max_mbytes", "name=\"" + enc(p.getName()) + "\"," + hostLbl + ",poolType=\"" + p.getType().name() + "\"", mb);
			}
		}
		if (en.contains("sag_is_jvm_memory_buffer_pool_capacity_mbytes")) {
			header(sb, "sag_is_jvm_memory_buffer_pool_capacity_mbytes", "The total number of allocated megabytes from NIO buffer pools", "gauge");
			for (BufferPoolMXBean bp : ManagementFactory.getPlatformMXBeans(BufferPoolMXBean.class))
				line(sb, "sag_is_jvm_memory_buffer_pool_capacity_mbytes", "name=\"" + enc(bp.getName()) + "\"," + hostLbl, bp.getTotalCapacity() / MB);
		}
		if (en.contains("sag_is_jvm_gc_collection_millis")) {
			header(sb, "sag_is_jvm_gc_collection_millis", "The total milliseconds from garbage collection cycle", "gauge");
			for (GarbageCollectorMXBean gc : ManagementFactory.getGarbageCollectorMXBeans())
				line(sb, "sag_is_jvm_gc_collection_millis", "name=\"" + enc(gc.getName()) + "\"," + hostLbl, gc.getCollectionTime());
		}
		ClassLoadingMXBean cl = ManagementFactory.getClassLoadingMXBean();
		gG(en, sb, "sag_is_jvm_classes_loaded_total", "The total number of current classes loaded in the JVM", hostLbl, cl.getLoadedClassCount());
		gG(en, sb, "sag_is_jvm_classes_total", "The total number of classes ever loaded in the JVM since startup", hostLbl, cl.getTotalLoadedClassCount());
		gG(en, sb, "sag_is_jvm_classes_unloaded_total", "The total number of classes unloaded in the JVM since startup", hostLbl, cl.getUnloadedClassCount());
		ThreadMXBean th = ManagementFactory.getThreadMXBean();
		try { if (th.isThreadContentionMonitoringSupported() && !th.isThreadContentionMonitoringEnabled())
				th.setThreadContentionMonitoringEnabled(true); } catch (Throwable ignore) {}
		ThreadInfo[] infos = th.getThreadInfo(th.getAllThreadIds());
		long sNew=0, sRunnable=0, sBlocked=0, sWaiting=0, sTimed=0, sTerminated=0;
		long nativeCnt=0, suspendCnt=0, blockedCnt=0, waitedCnt=0, blockedMs=0, waitedMs=0;
		for (ThreadInfo ti : infos) {
			if (ti == null) continue;
			switch (ti.getThreadState()) {
				case NEW: sNew++; break;
				case RUNNABLE: sRunnable++; break;
				case BLOCKED: sBlocked++; break;
				case WAITING: sWaiting++; break;
				case TIMED_WAITING: sTimed++; break;
				case TERMINATED: sTerminated++; break;
			}
			if (ti.isInNative()) nativeCnt++;
			if (ti.isSuspended()) suspendCnt++;
			blockedCnt += ti.getBlockedCount();
			waitedCnt  += ti.getWaitedCount();
			long bt = ti.getBlockedTime(); if (bt > 0) blockedMs += bt;
			long wt = ti.getWaitedTime();  if (wt > 0) waitedMs  += wt;
		}
		gG(en, sb, "sag_is_jvm_thread_state_new_count", "The number of NEW threads", hostLbl, sNew);
		gG(en, sb, "sag_is_jvm_thread_state_runnable_count", "The number of RUNNABLE threads", hostLbl, sRunnable);
		gG(en, sb, "sag_is_jvm_thread_state_blocked_count", "The number of BLOCKED threads", hostLbl, sBlocked);
		gG(en, sb, "sag_is_jvm_thread_state_waiting_count", "The number of WAITING threads without a timeout", hostLbl, sWaiting);
		gG(en, sb, "sag_is_jvm_thread_state_timed_waiting_count", "The number of WAITING threads with a timeout", hostLbl, sTimed);
		gG(en, sb, "sag_is_jvm_thread_state_terminated_count", "The number of TERMINATED threads", hostLbl, sTerminated);
		gG(en, sb, "sag_is_jvm_threads_native_count", "The number of threads in native code", hostLbl, nativeCnt);
		gG(en, sb, "sag_is_jvm_threads_suspend_count", "The number of suspended threads", hostLbl, suspendCnt);
		gG(en, sb, "sag_is_jvm_threads_blocked_count", "The number of blocked threads", hostLbl, blockedCnt);
		gG(en, sb, "sag_is_jvm_threads_waited_count", "The number of waited threads", hostLbl, waitedCnt);
		gG(en, sb, "sag_is_jvm_threads_blocked_millis", "Total number of milliseconds that threads have been in a blocked state", hostLbl, blockedMs);
		gG(en, sb, "sag_is_jvm_threads_waited_millis", "Total number of milliseconds that threads have waited for a lock", hostLbl, waitedMs);
		java.lang.management.OperatingSystemMXBean osBase = ManagementFactory.getOperatingSystemMXBean();
		gGd(en, sb, "sag_is_server_sysload_average", "Number of threads waiting for CPU resources (Linux-only)", hostLbl, osBase.getSystemLoadAverage());
		if (osBase instanceof com.sun.management.OperatingSystemMXBean) {
			com.sun.management.OperatingSystemMXBean os = (com.sun.management.OperatingSystemMXBean) osBase;
			gG(en, sb, "sag_is_server_proc_cpu_percent", "0-100 cpu percentage for the IS JVM", hostLbl, (long)(os.getProcessCpuLoad() * 100));
			gG(en, sb, "sag_is_server_proc_sys_percent", "0-100 cpu percentage for the OS", hostLbl, (long)(os.getCpuLoad() * 100));
			gG(en, sb, "sag_is_server_total_memory_mbytes", "Total physical memory in megabytes", hostLbl, os.getTotalMemorySize() / MB);
			gG(en, sb, "sag_is_server_used_memory_mbytes", "Used physical memory in megabytes", hostLbl, (os.getTotalMemorySize() - os.getFreeMemorySize()) / MB);
		}
		if (osBase instanceof com.sun.management.UnixOperatingSystemMXBean) {
			gG(en, sb, "sag_is_server_open_files_count", "Total used file descriptors (Linux-only)", hostLbl, ((com.sun.management.UnixOperatingSystemMXBean) osBase).getOpenFileDescriptorCount());
		}
		File root = new File("/");
		gG(en, sb, "sag_is_server_total_disk_mbytes", "Total disk space in megabytes", hostLbl, root.getTotalSpace() / MB);
		gG(en, sb, "sag_is_server_used_disk_mbytes", "Used disk space in megabytes", hostLbl, (root.getTotalSpace() - root.getUsableSpace()) / MB);
	}

	// gated gauge emit (long / double)
	static void gG(java.util.Set<String> en, StringBuilder sb, String name, String help, String hostLbl, long v) {
		if (en.contains(name)) emitG(sb, name, help, hostLbl, v);
	}
	static void gGd(java.util.Set<String> en, StringBuilder sb, String name, String help, String hostLbl, double v) {
		if (en.contains(name)) emitGd(sb, name, help, hostLbl, v);
	}
	// category master switch (default ON if unset)
	static boolean catOn(IData cats, String cat) {
		if (cats == null || cat == null) return true;
		IDataCursor c = cats.getCursor();
		Object v = IDataUtil.get(c, cat);
		c.destroy();
		return v == null ? true : "true".equalsIgnoreCase(String.valueOf(v));
	}
	// scalar fields of wm.server.query:getStats as name->String
	static java.util.Map<String,String> statsMap() throws Exception {
		IData out = Service.doInvoke("wm.server.query", "getStats", IDataFactory.create());
		java.util.Map<String,String> m = new java.util.HashMap<String,String>();
		IDataCursor c = out.getCursor();
		while (c.next()) {
			Object v = c.getValue();
			if (v != null && !(v instanceof IData) && !(v instanceof IData[])) m.put(c.getKey(), String.valueOf(v));
		}
		c.destroy();
		return m;
	}

	// ===== Task 3: server-aggregate families (42) — wm.server.query:getStats (license-free) =====
	// Native sources these same aggregates from getStats via PrometheusStatsProviderImpl, so emitting
	// the raw getStats field value under the sag_is_ name is exact parity by construction.
	// (collectServer removed — replaced by statsMap() + the config getStats loop in render)

	// ===== Task 2: per-service families (9) — wm.server.query:getServiceStats (license-free) =====
	// Each SvcStats record carries the per-service counters; record "name" is already the native
	// uppercase service label (e.g. JC.TOOLS.PUB.LIST:CONVERTTOSTRING). Samples are grouped by
	// family (header once, then one line per service) so the exposition is valid Prometheus.
	// ===== Per-service families — wm.server.query:getServiceStats, gated by the enabled-name set =====
	static void collectServiceStats(StringBuilder sb, String hostLbl, java.util.Set<String> en) throws Exception
	{
		IData out = Service.doInvoke("wm.server.query", "getServiceStats", IDataFactory.create());
		IDataCursor c = out.getCursor();
		IData[] recs = IDataUtil.getIDataArray(c, "SvcStats");
		c.destroy();
		if (recs == null) return;
		gSvc(en, sb, recs, hostLbl, "sag_is_service_number_access", "The number of times that the service has executed since the server was last started.", "sAccessTotal");
		gSvc(en, sb, recs, hostLbl, "sag_is_service_number_running", "The number of service is executing on the server at this instance.", "sRunning");
		gSvc(en, sb, recs, hostLbl, "sag_is_service_number_cache_hit", "The total number of times that a cached result for this service has been accessed (hit).", "cHitTotal");
		gSvc(en, sb, recs, hostLbl, "sag_is_service_cache_hit_ratio", "The percentage of service requests that have been fulfilled by retrieving the results from cache.", "cHitRatio");
		gSvc(en, sb, recs, hostLbl, "sag_is_service_cache_entries", "The number of active cache entries for the service.", "cEntries");
		gSvc(en, sb, recs, hostLbl, "sag_is_service_cache_expires", "The number of expired cache entries for the service.", "cExpires");
		gSvc(en, sb, recs, hostLbl, "sag_is_service_number_prefetch", "The total number of times the server has prefetched and cached the results for the service.", "cPrefetchTotal");
		gSvc(en, sb, recs, hostLbl, "sag_is_service_number_recent_prefetch", "The total number of times the server has prefetched and cached the results for the service in the last poll interval (10 mins default)", "cPrefetched");
		gSvc(en, sb, recs, hostLbl, "sag_is_service_number_errors", "The total number of errors for the service.", "cSvcErrors");
	}
	static void gSvc(java.util.Set<String> en, StringBuilder sb, IData[] recs, String hostLbl, String name, String help, String field) {
		if (en.contains(name)) svcFamily(sb, recs, hostLbl, name, help, field);
	}

	// emit one per-service family: HELP/TYPE once, then a line per service (empty/&nbsp; stats -> 0)
	static void svcFamily(StringBuilder sb, IData[] recs, String hostLbl, String name, String help, String field)
	{
		header(sb, name, help, "gauge");
		for (IData rec : recs) {
			if (rec == null) continue;
			IDataCursor rc = rec.getCursor();
			String svc = IDataUtil.getString(rc, "name");
			String v   = IDataUtil.getString(rc, field);
			rc.destroy();
			if (svc == null) continue;
			line(sb, name, "service=\"" + svc + "\"," + hostLbl, statVal(v));
		}
	}

	// webMethods stats use "&nbsp;" (and blanks) as the empty placeholder; native renders those as 0
	static String statVal(String v)
	{
		if (v == null) return "0";
		v = v.trim();
		if (v.isEmpty() || v.equals("&nbsp;") || v.equals(" ")) return "0";
		return v;
	}

	// read one scalar field from a getStats IData and emit it as a gauge family (skip if absent)
	// (srv removed — getStats families are data-driven in render via statsMap)

	static String hostname()
	{
		try { return InetAddress.getLocalHost().getHostName(); }
		catch (Exception e) { return "unknown"; }
	}

	// HELP+TYPE header (once per family)
	static void header(StringBuilder sb, String name, String help, String type)
	{
		sb.append("# HELP ").append(name).append(' ').append(help).append('\n');
		sb.append("# TYPE ").append(name).append(' ').append(type).append('\n');
	}

	// a single data line: name{labels} value   (no trailing timestamp — Prometheus stamps at scrape)
	static void line(StringBuilder sb, String name, String labels, Object value)
	{
		sb.append(name).append('{').append(labels).append("} ").append(value).append('\n');
	}

	// convenience: gauge family with a single host-labelled long value
	static void emitG(StringBuilder sb, String name, String help, String hostLbl, long value)
	{
		header(sb, name, help, "gauge");
		line(sb, name, hostLbl, value);
	}

	// convenience: gauge family with a single host-labelled double value
	static void emitGd(StringBuilder sb, String name, String help, String hostLbl, double value)
	{
		header(sb, name, help, "gauge");
		line(sb, name, hostLbl, value);
	}

	// native label-value encoding: space -> _space_, '-' -> _dash_, other non-alnum -> _
	static String enc(String s)
	{
		if (s == null) return "";
		StringBuilder b = new StringBuilder(s.length() + 8);
		for (int i = 0; i < s.length(); i++) {
			char ch = s.charAt(i);
			if (ch == ' ') b.append("_space_");
			else if (ch == '-') b.append("_dash_");
			else if (Character.isLetterOrDigit(ch)) b.append(ch);
			else b.append('_');
		}
		return b.toString();
	}

	// True if a URL alias with this exact name is already registered. listAlias is authoritative;
	// getAlias echoes the input name even when the alias is absent, so it can't gate creation.
	static boolean aliasExists(String alias)
	{
		try {
			IData out = Service.doInvoke("wm.server.httpUrlAlias", "listAlias", IDataFactory.create());
			IDataCursor c = out.getCursor();
			IData[] list = IDataUtil.getIDataArray(c, "aliasList");
			c.destroy();
			if (list != null) {
				for (IData rec : list) {
					if (rec == null) continue;
					IDataCursor rc = rec.getCursor();
					String a = IDataUtil.getString(rc, "alias");
					rc.destroy();
					if (alias.equals(a)) return true;
				}
			}
		} catch (Exception ignore) {}
		return false;
	}

	static void writeResponse(String body) throws ServiceException
	{
		IData in = IDataFactory.create();
		IDataCursor c = in.getCursor();
		IDataUtil.put(c, "string", body);
		IDataUtil.put(c, "contentType", "text/plain; version=0.0.4; charset=utf-8");
		c.destroy();
		try { Service.doInvoke("pub.flow", "setResponse", in); }
		catch (Exception e) { throw new ServiceException(e); }
	}

	// --- <<IS-END-SHARED>> ---
}
