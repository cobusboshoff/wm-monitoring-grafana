<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">unregisterAlias</value>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gVGVhcmRvd24gY291bnRlcnBhcnQgdG8gcmVnaXN0ZXJBbGlhczogcmVtb3ZlIHRoZSAvcGxh
dGZvcm0vbWV0cmljcyBhbGlhcyAoaWRlbXBvdGVudCBcdTIwMTQKLy8gbm8tb3AgaWYgYWxyZWFk
eSBhYnNlbnQpLiBIYW5kLWludm9rYWJsZSB2aWEgR0VUIG9yIFBPU1QuIGRlbGV0ZUFsaWFzIGFs
c28gcmVtb3ZlcyB0aGUKLy8gZW50cnkgZnJvbSBjb25maWcvdXJsYWxpYXMuY25mLCBzbyB0aGUg
YWxpYXMgc3RheXMgZ29uZSBhY3Jvc3MgcmVsb2FkcyBBTkQgcmVzdGFydHMKLy8gKHBlcm1hbmVu
dCByZW1vdmFsLCBub3QgYSBydW50aW1lIHRvZ2dsZSk7IGludm9rZSByZWdpc3RlckFsaWFzIHRv
IHJlc3RvcmUgaXQuCnRyeSB7CglTdHJpbmcgYWxpYXMgPSBjZmdBbGlhcyhsb2FkQ29uZmlnKCkp
OwoJaWYgKCFhbGlhc0V4aXN0cyhhbGlhcykpIHJldHVybjsKCWRlbEFsaWFzKGFsaWFzKTsKfSBj
YXRjaCAoRXhjZXB0aW9uIGUpIHsgdGhyb3cgbmV3IFNlcnZpY2VFeGNlcHRpb24oZSk7IH0K</value>
</Values>
