/* Prometheus Metrics Configuration — Carbon Web Components SPA over the InvCommonPlatformMetrics services.
   Carbon (cds-*) elements come from assets/carbon/carbon.js (offline bundle); this file renders
   view markup into <main id="gm-view"> and wires Carbon custom events (cds-toggle-changed,
   cds-search-input, cds-header-menu-button-toggled, clicks). Server side is unchanged. */
(function () {
  "use strict";
  var BASE = window.location.origin;
  function svc(n) { return BASE + "/invoke/inv.platform.metrics:" + n; }
  function jget(n) { return fetch(svc(n), { credentials: "same-origin" }).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); }); }
  function jpost(n, body) { return fetch(svc(n), { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); }
  function esc(s) { return (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function el(id) { return document.getElementById(id); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function fmtDur(sec) { sec = parseInt(sec || 0, 10); var d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60); return (d ? d + "d " : "") + (h ? h + "h " : "") + m + "m"; }

  var CFG = null, SNAP = null;
  var CAT = { server: "Server", jvm: "JVM", service: "Service" };

  // ---------- Carbon toast ----------
  function toast(msg, kind) {
    var host = el("gm-toast"); if (!host) return;
    var k = kind === "fail" ? "error" : (kind || "success");
    var n = document.createElement("cds-toast-notification");
    n.setAttribute("kind", k);
    n.setAttribute("title", k === "error" ? "Error" : "Done");
    n.setAttribute("subtitle", msg);
    n.setAttribute("timeout", "3600");
    n.addEventListener("cds-notification-closed", function () { if (n.parentNode) n.parentNode.removeChild(n); });
    host.appendChild(n);
    setTimeout(function () { if (n.parentNode) n.parentNode.removeChild(n); }, 4200);
  }

  function saveCfg() { return jpost("saveConfig", { config: CFG }).then(function (r) { if (!r.ok) throw new Error(r.status); return r; }); }

  function updatePill() {
    var p = el("gm-endpoint-pill"); if (!p || !SNAP) return;
    var up = SNAP.endpointUp === true || SNAP.endpointUp === "true";
    p.setAttribute("type", up ? "green" : "red");
    p.textContent = up ? "up · " + SNAP.familiesEmitted + "/" + SNAP.familiesTotal : "endpoint down";
  }

  // ---------- Environment accent (server-authoritative; pill + header strip) ----------
  function applyEnv() {
    if (!SNAP) return;
    var tier = String(SNAP.environment || "unknown").toLowerCase();
    if (!/^(dev|qa|uat|prod)$/.test(tier)) tier = "unknown";
    var label = SNAP.environmentLabel || tier.toUpperCase();
    var cls = "gmenv-" + tier;
    var pill = el("gm-env-pill");
    if (pill) { pill.textContent = label; pill.className = "gm-env-pill " + cls; }
    var strip = el("gm-env-strip");
    if (strip) strip.className = "gm-env-strip " + cls;
  }

  function pollSnap() {
    jget("snapshot").then(function (s) { SNAP = s; updatePill(); applyEnv(); if (curView() === "dashboard") renderDashboard(); }).catch(function () {});
  }

  function view() { return el("gm-view"); }
  function curView() { return (location.hash.replace("#", "") || "dashboard"); }
  function setActive(v) {
    // Carbon's side-nav-menu-item sets its parent menu active=true on activation but never clears it,
    // so parent highlights accumulate. Clear every menu first, then light only the current item's chain.
    qsa("cds-side-nav-menu").forEach(function (m) { try { m.active = false; } catch (e) {} });
    qsa("[data-view]").forEach(function (a) {
      var on = a.getAttribute("data-view") === v;
      try { a.active = on; } catch (e) {}
      if (on && a.closest) { var p = a.closest("cds-side-nav-menu"); if (p) { try { p.active = true; } catch (e) {} } }
    });
  }

  // ---------- Dashboard ----------
  function renderDashboard() {
    setActive("dashboard");
    var s = SNAP || {};
    var used = parseInt(s.heapUsedMb, 10) || 0, max = parseInt(s.heapMaxMb, 10) || 0, pct = max > 0 ? Math.round(100 * used / max) : 0;
    var up = s.endpointUp === true || s.endpointUp === "true";
    var errs = parseInt(s.errorsPerMin, 10) || 0;
    var heapLvl = pct >= 90 ? "crit" : pct >= 75 ? "warn" : "ok";
    var IC = {
      plug:  "M11.6 30a1 1 0 01-.6-1.1L12.8 17H8a1 1 0 01-.9-1.2l3-13A1 1 0 0111 2h10a1 1 0 011 1.2L20.3 11H25a1 1 0 01.8 1.6l-13 17a1 1 0 01-.8.4z",
      data:  "M16 4L2 11l14 7 14-7zm0 11.7L5.6 11 16 6.3 26.4 11zM4 16.5v2.3l12 6.4 12-6.4v-2.3l-12 6.4z",
      timer: "M15 11h2v9h-2zm-2-9h6v2h-6zM28 9l-1.4-1.4-2.2 2.2A11 11 0 1025.5 11.5zM16 26a9 9 0 119-9 9 9 0 01-9 9z",
      chip:  "M11 11v10h10V11zm8 8h-6v-6h6zM30 13v-2h-4V8a2 2 0 00-2-2h-3V2h-2v4h-6V2h-2v4H8a2 2 0 00-2 2v3H2v2h4v6H2v2h4v3a2 2 0 002 2h3v4h2v-4h6v4h2v-4h3a2 2 0 002-2v-3h4v-2h-4v-6zM24 24H8V8h16z",
      pulse: "M12 29a1 1 0 01-.92-.62L6.33 17H2v-2h5a1 1 0 01.92.62L12 25.28 20.06 3.65A1 1 0 0121 3a1 1 0 01.93.68L25.72 15H30v2h-5a1 1 0 01-.95-.68L21 7 12.94 28.35A1 1 0 0112 29z",
      warn:  "M16 2L2 28h28zm0 4.2L26.3 26H5.7zM15 12h2v8h-2zm1 10a1.5 1.5 0 101.5 1.5A1.5 1.5 0 0016 22z",
      flow:  "M20 10l-1.4 1.4L23.2 16H4v2h19.2l-4.6 4.6L20 24l7-7z"
    };
    function kpi(o) {
      var bar = o.bar != null ? '<div class="gm-kpi-bar ' + o.lvl + '"><i style="width:' + Math.min(100, o.bar) + '%"></i></div>' : "";
      return '<cds-tile class="gm-kpi" style="--gm-accent:' + o.accent + '">' +
        '<div class="gm-kpi-top"><span class="gm-kpi-lbl">' + esc(o.lbl) + '</span>' +
        '<svg class="gm-kpi-ic" viewBox="0 0 32 32" fill="currentColor" aria-hidden="true"><path d="' + o.ic + '"/></svg></div>' +
        '<div class="gm-kpi-num">' + o.num + '</div><div class="gm-kpi-sub">' + esc(o.sub || "") + "</div>" + bar + "</cds-tile>";
    }
    view().innerHTML =
      '<h1 class="gm-view-title">Overview</h1>' +
      '<p class="gm-view-sub">Live health of the <span class="gm-code">/platform/metrics</span> exporter</p>' +
      '<div class="gm-tiles">' +
        kpi({ lbl: "Endpoint", ic: IC.plug, accent: "#0f62fe", num: (up ? '<span class="gm-up">&#9679; up</span>' : '<span class="gm-down">&#9679; down</span>'), sub: "/platform/metrics" }) +
        kpi({ lbl: "Families", ic: IC.data, accent: "#0072c3", num: (s.familiesEmitted || 0) + ' <span class="gm-kpi-unit">/ ' + (s.familiesTotal || 0) + "</span>", sub: "enabled" }) +
        kpi({ lbl: "Uptime", ic: IC.timer, accent: "#009d9a", num: esc(fmtDur(s.uptimeSec)), sub: "server" }) +
        kpi({ lbl: "Heap", ic: IC.chip, accent: "#8a3ffc", num: used + ' <span class="gm-kpi-unit">/ ' + max + ' MB</span>', sub: pct + "%", bar: pct, lvl: heapLvl }) +
        kpi({ lbl: "Threads", ic: IC.pulse, accent: "#1192e8", num: String(s.threads || 0), sub: "jvm" }) +
        kpi({ lbl: "Errors/min", ic: IC.warn, accent: "#da1e28", num: (errs > 0 ? '<span class="gm-down">' + errs + "</span>" : String(errs)), sub: "service" }) +
        kpi({ lbl: "Req/min", ic: IC.flow, accent: "#24a148", num: String(s.reqPerMin || 0), sub: "completions" }) +
      "</div>";
  }

  // ---------- Metrics (per category) — Carbon DataTable ----------
  function renderMetrics(cat) {
    setActive("metrics-" + cat);
    if (!CFG) { view().innerHTML = '<p class="gm-muted">loading…</p>'; return; }
    var rows = (CFG.families || []).filter(function (f) { return f.category === cat; });
    var catOn = !!(CFG.categories && CFG.categories[cat] === true);
    view().innerHTML =
      '<h1 class="gm-view-title">' + CAT[cat] + ' Metrics</h1>' +
      '<p class="gm-view-sub">Built-in &middot; ' + rows.length + ' families &middot; changes apply on the next scrape</p>' +
      '<div class="gm-toolbar gm-section">' +
        '<cds-toggle size="sm" id="gm-cat" label-text="" label-a="" label-b="" hide-label ' + (catOn ? "checked" : "") + '></cds-toggle>' +
        '<span><b>' + CAT[cat] + ' Metrics</b> <span class="gm-muted">— master switch for this category</span></span>' +
      "</div>" +
      '<cds-table id="gm-table">' +
        '<cds-table-toolbar slot="toolbar">' +
          '<cds-table-toolbar-content>' +
            '<cds-table-toolbar-search id="gm-search" placeholder="Search ' + rows.length + ' metrics"></cds-table-toolbar-search>' +
            '<cds-button kind="ghost" size="sm" id="gm-all">Enable all</cds-button>' +
            '<cds-button kind="ghost" size="sm" id="gm-none">Disable all</cds-button>' +
            '<cds-button kind="primary" size="sm" id="gm-save">Save</cds-button>' +
          "</cds-table-toolbar-content>" +
        "</cds-table-toolbar>" +
        '<cds-table-head><cds-table-header-row>' +
          '<cds-table-header-cell style="width:4rem">On</cds-table-header-cell>' +
          '<cds-table-header-cell>Metric</cds-table-header-cell>' +
          '<cds-table-header-cell style="width:6rem">Type</cds-table-header-cell>' +
          '<cds-table-header-cell>Description</cds-table-header-cell>' +
        "</cds-table-header-row></cds-table-head>" +
        '<cds-table-body id="gm-rows"></cds-table-body>' +
      "</cds-table>";

    function famOf(name) { return rows.filter(function (f) { return f.name === name; })[0]; }
    function draw(filter) {
      filter = (filter || "").toLowerCase();
      var html = "";
      rows.forEach(function (f) {
        if (filter && f.name.toLowerCase().indexOf(filter) < 0 && (f.help || "").toLowerCase().indexOf(filter) < 0) return;
        html += "<cds-table-row>" +
          '<cds-table-cell><cds-toggle size="sm" class="gm-fam" data-name="' + esc(f.name) + '" label-text="" label-a="" label-b="" hide-label ' +
            (f.enabled === true ? "checked" : "") + (catOn ? "" : " disabled") + "></cds-toggle></cds-table-cell>" +
          '<cds-table-cell><span class="gm-metric-name">' + esc(f.name) + "</span></cds-table-cell>" +
          '<cds-table-cell><cds-tag type="cool-gray" size="sm">' + esc(f.type) + "</cds-tag></cds-table-cell>" +
          '<cds-table-cell class="gm-muted">' + esc(f.help || "") + "</cds-table-cell>" +
          "</cds-table-row>";
      });
      el("gm-rows").innerHTML = html || '<cds-table-row><cds-table-cell colspan="4" class="gm-muted">no match</cds-table-cell></cds-table-row>';
      qsa(".gm-fam").forEach(function (c) {
        c.addEventListener("cds-toggle-changed", function (e) {
          var f = famOf(c.getAttribute("data-name")); if (f) f.enabled = (e.detail ? e.detail.checked : c.checked) === true;
        });
      });
    }
    draw("");
    el("gm-search").addEventListener("cds-search-input", function (e) { draw(e.detail ? e.detail.value : this.value); });
    el("gm-cat").addEventListener("cds-toggle-changed", function (e) {
      CFG.categories[cat] = (e.detail ? e.detail.checked : this.checked) === true;
      qsa(".gm-fam").forEach(function (c) { if (CFG.categories[cat]) c.removeAttribute("disabled"); else c.setAttribute("disabled", ""); });
    });
    el("gm-all").addEventListener("click", function () { rows.forEach(function (f) { f.enabled = true; }); draw(el("gm-search").value || ""); });
    el("gm-none").addEventListener("click", function () { rows.forEach(function (f) { f.enabled = false; }); draw(el("gm-search").value || ""); });
    el("gm-save").addEventListener("click", function () { saveCfg().then(function () { toast("Saved — applies on next scrape"); pollSnap(); }).catch(function (e) { toast("Save failed (" + e.message + ")", "fail"); }); });
  }

  function renderCustom() {
    setActive("metrics-custom");
    view().innerHTML = '<h1 class="gm-view-title">Custom Metrics</h1>' +
      '<p class="gm-view-sub">coming soon</p>' +
      '<cds-tile><p class="gm-muted">Define your own metrics — e.g. expose a JMX MBean attribute ' +
      '(<span class="gm-code">ObjectName/attribute</span>) as a <span class="gm-code">sag_is_*</span>-style metric — ' +
      'in a future release. The exporter engine already dispatches a <span class="gm-code">jmx</span> source type for this.</p></cds-tile>';
  }

  // ---------- Settings: URL alias ----------
  function renderAlias() {
    setActive("settings-alias");
    if (!CFG) { view().innerHTML = '<p class="gm-muted">loading…</p>'; return; }
    var alias = (CFG.endpoint && CFG.endpoint.alias) || "platform/metrics";
    view().innerHTML = '<h1 class="gm-view-title">URL Alias</h1>' +
      '<p class="gm-view-sub">The scrape endpoint path</p>' +
      '<cds-tile>' +
        '<div class="gm-form-row"><cds-text-input id="gm-alias" label="Alias path" value="' + esc(alias) + '"></cds-text-input></div>' +
        '<p class="gm-muted">Scraped at <span class="gm-code">/' + esc(alias) + '</span> &rarr; <span class="gm-code">invoke/inv.platform.metrics:render</span>. ' +
        'Changing this re-registers the alias (update the Prometheus/Dynatrace scrape config to match).</p>' +
        '<cds-button kind="primary" id="gm-alias-save">Apply</cds-button>' +
      "</cds-tile>";
    el("gm-alias-save").addEventListener("click", function () {
      var v = (el("gm-alias").value || "").trim().replace(/^\/+/, "");
      if (!v) { toast("Alias cannot be empty", "fail"); return; }
      CFG.endpoint = CFG.endpoint || {}; CFG.endpoint.alias = v;
      saveCfg().then(function () { toast("Alias saved & re-registered as /" + v); }).catch(function (e) { toast("Save failed (" + e.message + ")", "fail"); });
    });
  }

  // ---------- Settings: CSV import/export ----------
  function renderIO() {
    setActive("settings-io");
    view().innerHTML = '<h1 class="gm-view-title">Import / Export</h1>' +
      '<p class="gm-view-sub">Bulk metric configuration as CSV</p>' +
      '<cds-tile class="gm-section"><h3 style="margin:0 0 .5rem;font-weight:600">Export</h3>' +
        '<p class="gm-muted">Download the current configuration (name, category, type, enabled) as CSV.</p>' +
        '<cds-button kind="primary" id="gm-export">Export CSV</cds-button></cds-tile>' +
      '<cds-tile><h3 style="margin:0 0 .5rem;font-weight:600">Import</h3>' +
        '<p class="gm-muted">Upload a CSV (columns <span class="gm-code">name,enabled</span>; extras ignored, unknown names skipped) to bulk-set enabled metrics.</p>' +
        '<input id="gm-import-file" type="file" accept=".csv,text/csv" style="margin:.5rem 0"> ' +
        '<cds-button kind="primary" id="gm-import">Import &amp; Save</cds-button>' +
        '<div id="gm-import-msg" class="gm-muted" style="margin-top:.5rem"></div></cds-tile>';
    el("gm-export").addEventListener("click", exportCsv);
    el("gm-import").addEventListener("click", importCsv);
  }
  function exportCsv() {
    var lines = ["name,category,type,enabled"];
    (CFG.families || []).forEach(function (f) { lines.push([f.name, f.category, f.type, f.enabled === true].join(",")); });
    var blob = new Blob([lines.join("\n")], { type: "text/csv" });
    var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "platform-metrics-config.csv";
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    toast("Exported " + (CFG.families || []).length + " rows");
  }
  function importCsv() {
    var f = el("gm-import-file").files[0];
    if (!f) { toast("Choose a CSV file first", "fail"); return; }
    var reader = new FileReader();
    reader.onload = function () {
      var text = reader.result, rows = text.split(/\r?\n/).filter(Boolean);
      var header = rows.shift().split(",").map(function (s) { return s.trim().toLowerCase(); });
      var ni = header.indexOf("name"), ei = header.indexOf("enabled");
      if (ni < 0 || ei < 0) { el("gm-import-msg").textContent = "CSV must have 'name' and 'enabled' columns."; return; }
      var want = {}; rows.forEach(function (line) { var c = line.split(","); if (c[ni]) want[c[ni].trim()] = /^(true|1|yes|on)$/i.test((c[ei] || "").trim()); });
      var applied = 0, unknown = 0;
      (CFG.families || []).forEach(function (fam) { if (fam.name in want) { fam.enabled = want[fam.name]; applied++; } });
      Object.keys(want).forEach(function (n) { if (!(CFG.families || []).some(function (fam) { return fam.name === n; })) unknown++; });
      saveCfg().then(function () {
        el("gm-import-msg").textContent = "Applied " + applied + " metric(s)" + (unknown ? ", " + unknown + " unknown skipped" : "") + ". Saved.";
        toast("Imported " + applied + " metric(s)"); pollSnap();
      }).catch(function (e) { toast("Save failed (" + e.message + ")", "fail"); });
    };
    reader.readAsText(f);
  }

  // ---------- router ----------
  function route() {
    var v = curView();
    if (v === "dashboard") renderDashboard();
    else if (v === "metrics-server") renderMetrics("server");
    else if (v === "metrics-jvm") renderMetrics("jvm");
    else if (v === "metrics-service") renderMetrics("service");
    else if (v === "metrics-custom") renderCustom();
    else if (v === "settings-alias") renderAlias();
    else if (v === "settings-io") renderIO();
    else renderDashboard();
    if (NAV_NARROW.matches) { var _n = el("gm-sidenav"); if (_n) _n.expanded = false; } // close drawer after navigating
  }

  // ---------- theme (Carbon white / g100, persisted) ----------
  function initTheme() {
    var btn = el("gm-theme"); if (!btn) return;
    function paint() {
      var dark = document.documentElement.getAttribute("data-carbon-theme") === "g100";
      var moon = document.querySelector(".gm-ic-moon"), sun = document.querySelector(".gm-ic-sun");
      if (moon) moon.style.display = dark ? "none" : "";
      if (sun) sun.style.display = dark ? "" : "none";
    }
    paint();
    btn.addEventListener("click", function () {
      var next = document.documentElement.getAttribute("data-carbon-theme") === "g100" ? "white" : "g100";
      document.documentElement.setAttribute("data-carbon-theme", next);
      try { localStorage.setItem("gm_theme", next); } catch (e) {}
      paint();
    });
  }

  // ---------- nav (Carbon side-nav rail toggle via header menu button) ----------
  var NAV_NARROW = window.matchMedia("(max-width: 65.98rem)");
  function initNav() {
    // collapse-mode="responsive": Carbon hides the rail below its lg breakpoint as a native overlay
    // drawer; the burger just toggles the side-nav's own `expanded` property (Carbon owns show/hide).
    var btn = el("gm-navtoggle"), nav = el("gm-sidenav");
    if (btn && nav) btn.addEventListener("cds-header-menu-button-toggled", function (e) {
      nav.expanded = e.detail ? e.detail.active : !nav.expanded;
    });
    // the static `expanded` attribute is desktop markup; below lg it would open the overlay drawer
    if (nav && NAV_NARROW.matches) nav.expanded = false;
    NAV_NARROW.addEventListener("change", function (e) { if (nav) nav.expanded = !e.matches; });
    // Explore-docs global action → package docs tab on the home page
    var ex = el("gm-explore");
    if (ex) ex.addEventListener("click", function () { window.location.href = "index.html#document"; });
  }

  function init() {
    initTheme();
    initNav();
    jget("getConfig").then(function (c) {
      CFG = c;
      route();
      pollSnap();
      setInterval(pollSnap, (parseInt(c.refreshInterval, 10) || 10) * 1000);
    }).catch(function () {
      view().innerHTML = '<cds-inline-notification kind="error" title="Configuration unavailable" subtitle="Check that you are authenticated (Administrator)." hide-close-button></cds-inline-notification>';
    });
    window.addEventListener("hashchange", route);
  }
  if (document.readyState !== "loading") init(); else document.addEventListener("DOMContentLoaded", init);
})();
