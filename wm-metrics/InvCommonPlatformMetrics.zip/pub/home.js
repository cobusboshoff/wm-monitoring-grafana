/* Platform Metrics home tab (package home page) — live health widget + metrics config UI.
   Self-contained (no dependency on the Designer Angular app). Calls the package's own services:
   inv.platform.metrics:{snapshot,getConfig,saveConfig}. @delite/Bootstrap classes for styling. */
(function () {
  "use strict";
  var BASE = window.location.origin;
  // No credentials in source: the homepage is Administrator-gated (pub/.access), so the browser's
  // authenticated same-origin session carries these calls automatically.
  function svc(n) { return BASE + "/invoke/inv.platform.metrics:" + n; }
  function jget(n) { return fetch(svc(n), { credentials: "same-origin" }).then(function (r) { return r.json(); }); }
  function jpost(n, body) {
    return fetch(svc(n), { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  }
  function esc(s) { return (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;"); }
  function truncate(s, n) { s = s || ""; return s.length > n ? s.slice(0, n) + "…" : s; }
  function fmtDur(sec) {
    sec = parseInt(sec || 0, 10);
    var d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60);
    return (d ? d + "d " : "") + (h ? h + "h " : "") + m + "m";
  }

  var CFG = null;
  var CAT_LABELS = { server: "Server Metrics", jvm: "JVM Metrics", service: "Service Metrics" };
  var CAT_ORDER = ["server", "jvm", "service"];

  // ---- live widget ----
  function card(label, value, sub, cls) {
    return '<div class="col-6 col-md-3"><div class="p-3 border rounded ' + (cls || "") + '" style="background:#fff;">' +
      '<div class="text-muted small">' + label + '</div>' +
      '<div style="font-size:1.5rem;font-weight:600;line-height:1.2;">' + value + '</div>' +
      '<div class="small text-muted">' + (sub || "") + '</div></div></div>';
  }
  function renderSnapshot(s) {
    var el = document.getElementById("gm-cards"); if (!el) return;
    var up = s.endpointUp === true || s.endpointUp === "true";
    var used = parseInt(s.heapUsedMb, 10), max = parseInt(s.heapMaxMb, 10);
    var pct = max > 0 ? Math.round(100 * used / max) : 0;
    el.innerHTML =
      card("Endpoint", up ? '<span style="color:#198754;">&#9679; up</span>' : '<span style="color:#dc3545;">&#9679; down</span>', "/platform/metrics") +
      card("Families emitted", s.familiesEmitted + " / " + s.familiesTotal, "enabled / available") +
      card("Uptime", fmtDur(s.uptimeSec), "server") +
      card("Heap", used + " / " + max + " MB", pct + "%", pct >= 90 ? "border-danger" : (pct >= 80 ? "border-warning" : "")) +
      card("Threads", s.threads, "JVM") +
      card("Errors/min", s.errorsPerMin, "service errors") +
      card("Requests/min", s.reqPerMin, "completions");
  }
  function pollSnapshot() {
    jget("snapshot").then(renderSnapshot).catch(function () {
      var el = document.getElementById("gm-cards");
      if (el && !el.innerHTML) el.innerHTML = '<div class="col text-danger small">snapshot unavailable (auth?)</div>';
    });
  }

  // ---- config UI ----
  function renderConfig(cfg) {
    CFG = cfg;
    var byCat = {};
    (cfg.families || []).forEach(function (f) { (byCat[f.category] = byCat[f.category] || []).push(f); });
    var html = "";
    CAT_ORDER.forEach(function (cat) {
      var rows = byCat[cat] || []; if (!rows.length) return;
      var catOn = cfg.categories && cfg.categories[cat] === true;
      html += '<div class="card mb-3"><div class="card-header d-flex align-items-center">' +
        '<div class="form-check form-switch me-2 mb-0"><input class="form-check-input gm-cat" type="checkbox" data-cat="' + cat + '" ' + (catOn ? "checked" : "") + '></div>' +
        '<b>' + CAT_LABELS[cat] + '</b><span class="ms-2 text-muted small">(' + rows.length + ')</span></div>' +
        '<div class="card-body p-0" style="max-height:16rem;overflow:auto;"><table class="table table-sm mb-0 align-middle">' +
        '<thead><tr><th style="width:2.5rem;"></th><th>Metric</th><th style="width:5rem;">type</th><th>description</th></tr></thead><tbody>';
      rows.forEach(function (f) {
        html += '<tr><td><input class="form-check-input gm-fam" type="checkbox" data-name="' + f.name + '" ' +
          (f.enabled === true ? "checked" : "") + (catOn ? "" : " disabled") + '></td>' +
          '<td><code>' + f.name + '</code></td><td class="text-muted small">' + f.type + '</td>' +
          '<td class="text-muted small" title="' + esc(f.help) + '">' + esc(truncate(f.help, 70)) + '</td></tr>';
      });
      html += "</tbody></table></div></div>";
    });
    html += '<div class="card mb-3"><div class="card-header"><b>Additional (custom metrics)</b> <span class="badge bg-secondary">coming soon</span></div>' +
      '<div class="card-body text-muted small">Define custom metrics (e.g. a JMX MBean attribute &rarr; a sag_is_ metric) here in a future release.</div></div>';
    var el = document.getElementById("gm-config"); el.innerHTML = html;
    // category master toggle enables/disables its family checkboxes
    Array.prototype.forEach.call(el.querySelectorAll(".gm-cat"), function (cb) {
      cb.addEventListener("change", function () {
        Array.prototype.forEach.call(cb.closest(".card").querySelectorAll(".gm-fam"), function (f) { f.disabled = !cb.checked; });
      });
    });
  }

  window.platformMetricsSave = function () {
    if (!CFG) return;
    var cats = {}, enabled = {};
    Array.prototype.forEach.call(document.querySelectorAll(".gm-cat"), function (cb) { cats[cb.getAttribute("data-cat")] = cb.checked; });
    Array.prototype.forEach.call(document.querySelectorAll(".gm-fam"), function (cb) { enabled[cb.getAttribute("data-name")] = cb.checked; });
    Object.keys(cats).forEach(function (c) { CFG.categories[c] = cats[c]; });
    (CFG.families || []).forEach(function (f) { if (f.name in enabled) f.enabled = enabled[f.name]; });
    var msg = document.getElementById("gm-savemsg");
    msg.textContent = "saving…"; msg.className = "me-2 small text-muted";
    jpost("saveConfig", { config: CFG }).then(function (r) {
      if (r.ok) { msg.textContent = "saved ✓"; msg.className = "me-2 small text-success"; pollSnapshot(); }
      else { msg.textContent = "save failed (" + r.status + ")"; msg.className = "me-2 small text-danger"; }
    }).catch(function () { msg.textContent = "save failed"; msg.className = "me-2 small text-danger"; });
  };

  function init() {
    jget("getConfig").then(function (cfg) {
      renderConfig(cfg);
      pollSnapshot();
      setInterval(pollSnapshot, (parseInt(cfg.refreshInterval, 10) || 10) * 1000);
    }).catch(function () {
      var el = document.getElementById("gm-config");
      if (el) el.innerHTML = '<div class="text-danger">config unavailable (auth?)</div>';
      pollSnapshot();
    });
  }
  if (document.readyState !== "loading") init();
  else document.addEventListener("DOMContentLoaded", init);
})();
