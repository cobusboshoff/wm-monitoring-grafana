app.service('myserv', function() {
          this.getServiceList = function () {
    return [{"serviceName":"inv.platform.metrics:registerAlias","description":"Idempotent repair service: (re)registers the /platform/metrics URL alias for invoke/inv.platform.metrics:render. No-op if already present (listAlias guard). The alias is normally registered from config/urlalias.cnf at activation; invoke this to restore it if it was deleted. GET or POST.","serviceinputs":[],"serviceoutputs":[]},{"serviceName":"inv.platform.metrics:render","description":"Builds the Prometheus exposition served at /platform/metrics: JVM and OS families from java.lang/com.sun.management MXBeans plus server aggregates from wm.server.query:getStats. One-to-one with the MCR native sag_is_ catalog (Server and JVM). No input; writes the response via pub.flow:setResponse.","serviceinputs":[],"serviceoutputs":[]},{"serviceName":"inv.platform.metrics:unregisterAlias","description":"Idempotent teardown service: removes the /platform/metrics URL alias AND its config/urlalias.cnf entry, so it stays removed across reloads and restarts (permanent, not a runtime toggle). No-op if already absent. Use registerAlias to restore it. GET or POST.","serviceinputs":[],"serviceoutputs":[]}];
}
this.getISEndpoint = function() { 
 return 'http://192.168.68.114:5555/';
}
this.getAPIList = function() { 
 return [];
}
this.getCreatedTime = function() { 
 return "24-07-2026 14:36:17 SAST";
}
this.getPackageInfo = function(){
 return{"packageName":"InvCommonPlatformMetrics","version":"0.1","buildNumber":"","description":"Investec Platform Metrics in-process sag_is_* exporter (license-free bridge). Serves /platform/metrics."};
}
});
